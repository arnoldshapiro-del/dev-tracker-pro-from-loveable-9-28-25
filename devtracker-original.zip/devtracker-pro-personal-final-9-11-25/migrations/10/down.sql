
ALTER TABLE projects DROP COLUMN mocha_development_url;
ALTER TABLE projects DROP COLUMN github_development_url;
ALTER TABLE projects DROP COLUMN netlify_development_url;
ALTER TABLE projects DROP COLUMN vercel_development_url;
ALTER TABLE projects DROP COLUMN twilio_development_url;
ALTER TABLE projects DROP COLUMN custom_platform_1_development_url;
ALTER TABLE projects DROP COLUMN custom_platform_2_development_url;
ALTER TABLE projects DROP COLUMN custom_platform_3_development_url;
