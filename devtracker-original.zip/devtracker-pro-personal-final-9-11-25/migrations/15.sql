
-- Team Collaboration Features (from Linear, Notion, Slack)
CREATE TABLE teams (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  team_name TEXT NOT NULL,
  team_description TEXT,
  team_code TEXT UNIQUE,
  is_public BOOLEAN DEFAULT 0,
  max_members INTEGER DEFAULT 10,
  subscription_tier TEXT DEFAULT 'free',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE team_members (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  member_email TEXT NOT NULL,
  role TEXT DEFAULT 'member',
  permissions TEXT DEFAULT '[]',
  invite_status TEXT DEFAULT 'pending',
  joined_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE team_projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id INTEGER NOT NULL,
  project_id INTEGER NOT NULL,
  project_role TEXT DEFAULT 'contributor',
  can_edit BOOLEAN DEFAULT 1,
  can_deploy BOOLEAN DEFAULT 0,
  can_delete BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Real-time Notifications (from Slack, Discord, Linear)
CREATE TABLE notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  notification_type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  action_url TEXT,
  is_read BOOLEAN DEFAULT 0,
  priority TEXT DEFAULT 'normal',
  category TEXT DEFAULT 'general',
  metadata TEXT DEFAULT '{}',
  expires_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notification_preferences (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL UNIQUE,
  email_notifications BOOLEAN DEFAULT 1,
  push_notifications BOOLEAN DEFAULT 1,
  sms_notifications BOOLEAN DEFAULT 0,
  team_activity BOOLEAN DEFAULT 1,
  project_updates BOOLEAN DEFAULT 1,
  deployment_alerts BOOLEAN DEFAULT 1,
  credit_warnings BOOLEAN DEFAULT 1,
  quiet_hours_start TEXT DEFAULT '22:00',
  quiet_hours_end TEXT DEFAULT '08:00',
  timezone TEXT DEFAULT 'America/New_York',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Advanced Analytics (from Notion, Linear, GitHub Insights)
CREATE TABLE analytics_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  event_name TEXT NOT NULL,
  project_id INTEGER,
  team_id INTEGER,
  properties TEXT DEFAULT '{}',
  session_id TEXT,
  ip_address TEXT,
  user_agent TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE custom_dashboards (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  dashboard_name TEXT NOT NULL,
  dashboard_type TEXT DEFAULT 'personal',
  widgets_config TEXT NOT NULL,
  layout_config TEXT DEFAULT '{}',
  is_public BOOLEAN DEFAULT 0,
  team_id INTEGER,
  view_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Video Consultations (from SimplePractice, Doxy.me, Zoom Healthcare)
CREATE TABLE video_consultations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  appointment_id INTEGER NOT NULL,
  patient_id INTEGER NOT NULL,
  provider_id TEXT NOT NULL,
  meeting_url TEXT NOT NULL,
  meeting_id TEXT UNIQUE,
  meeting_password TEXT,
  platform TEXT DEFAULT 'webrtc',
  status TEXT DEFAULT 'scheduled',
  started_at DATETIME,
  ended_at DATETIME,
  duration_minutes INTEGER,
  recording_url TEXT,
  recording_consent BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Enhanced Patient Portal (from Epic MyChart, Athenahealth)
CREATE TABLE patient_portal_access (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL,
  access_code TEXT UNIQUE NOT NULL,
  qr_code_url TEXT,
  portal_password TEXT,
  email_verified BOOLEAN DEFAULT 0,
  phone_verified BOOLEAN DEFAULT 0,
  last_login_at DATETIME,
  login_attempts INTEGER DEFAULT 0,
  is_locked BOOLEAN DEFAULT 0,
  verification_token TEXT,
  password_reset_token TEXT,
  password_reset_expires DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patient_documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL,
  document_title TEXT NOT NULL,
  document_type TEXT NOT NULL,
  file_url TEXT NOT NULL,
  file_size INTEGER,
  mime_type TEXT,
  is_sensitive BOOLEAN DEFAULT 0,
  uploaded_by TEXT NOT NULL,
  patient_can_view BOOLEAN DEFAULT 1,
  patient_can_download BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Automated Billing (from Kareo, SimplePractice, Athenahealth)
CREATE TABLE billing_codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  code_type TEXT NOT NULL,
  description TEXT NOT NULL,
  base_fee REAL NOT NULL,
  insurance_fee REAL,
  self_pay_fee REAL,
  category TEXT NOT NULL,
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL,
  appointment_id INTEGER,
  invoice_number TEXT UNIQUE NOT NULL,
  subtotal REAL NOT NULL,
  tax_amount REAL DEFAULT 0,
  total_amount REAL NOT NULL,
  status TEXT DEFAULT 'draft',
  due_date DATE,
  paid_date DATE,
  payment_method TEXT,
  payment_reference TEXT,
  insurance_claim_id TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoice_line_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_id INTEGER NOT NULL,
  billing_code_id INTEGER NOT NULL,
  description TEXT NOT NULL,
  quantity INTEGER DEFAULT 1,
  unit_price REAL NOT NULL,
  line_total REAL NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- AI-Powered Project Insights (from GitHub Copilot, Linear AI, Notion AI)
CREATE TABLE ai_insights (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  insight_type TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  confidence_score REAL NOT NULL,
  action_items TEXT DEFAULT '[]',
  predicted_impact TEXT,
  data_sources TEXT DEFAULT '[]',
  is_dismissed BOOLEAN DEFAULT 0,
  is_implemented BOOLEAN DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Smart Scheduling (from Calendly, Acuity, SimplePractice)
CREATE TABLE scheduling_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  rule_name TEXT NOT NULL,
  appointment_type TEXT,
  min_notice_hours INTEGER DEFAULT 24,
  max_advance_days INTEGER DEFAULT 90,
  buffer_before_minutes INTEGER DEFAULT 0,
  buffer_after_minutes INTEGER DEFAULT 0,
  allow_back_to_back BOOLEAN DEFAULT 1,
  auto_confirm BOOLEAN DEFAULT 0,
  require_payment BOOLEAN DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE smart_availability (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  date_override DATE,
  time_slots TEXT NOT NULL,
  max_appointments INTEGER DEFAULT 1,
  appointment_types TEXT DEFAULT '[]',
  special_pricing REAL,
  notes TEXT,
  is_recurring BOOLEAN DEFAULT 0,
  recurrence_pattern TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
