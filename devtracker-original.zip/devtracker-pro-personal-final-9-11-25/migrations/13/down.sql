
DELETE FROM projects WHERE user_id = 'demo-user';
