import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router';
import { 
  Search, 
  Command, 
  Hash, 
  Settings, 
  BarChart3, 
  Database, 
  Brain, 
  Rocket,
  Heart,
  Zap,
  GitBranch,
  MessageSquare,
  Clock,
  Star,
  Upload,
  HelpCircle,
  Key,
  Shield,
  Phone,
  Plus,
  Edit,
  ChevronRight,
  Keyboard
} from 'lucide-react';

interface CommandItem {
  id: string;
  title: string;
  subtitle?: string;
  icon: React.ComponentType<any>;
  action: () => void;
  category: 'navigation' | 'actions' | 'projects' | 'recent' | 'help';
  keywords: string[];
  shortcut?: string;
}

interface CommandPaletteProps {
  projects?: any[];
  isOpen: boolean;
  onClose: () => void;
}

export default function CommandPalette({ projects = [], isOpen, onClose }: CommandPaletteProps) {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);

  // Navigation commands
  const navigationCommands: CommandItem[] = [
    {
      id: 'nav-dashboard',
      title: 'Dashboard',
      subtitle: 'View your project overview',
      icon: BarChart3,
      action: () => { navigate('/dashboard'); onClose(); },
      category: 'navigation',
      keywords: ['dashboard', 'home', 'overview', 'stats', 'metrics'],
      shortcut: 'D'
    },
    {
      id: 'nav-projects',
      title: 'Projects',
      subtitle: 'Manage your AI development projects',
      icon: Database,
      action: () => { navigate('/projects'); onClose(); },
      category: 'navigation',
      keywords: ['projects', 'apps', 'development', 'ai', 'manage'],
      shortcut: 'P'
    },
    {
      id: 'nav-analytics',
      title: 'Analytics',
      subtitle: 'View performance insights',
      icon: BarChart3,
      action: () => { navigate('/analytics'); onClose(); },
      category: 'navigation',
      keywords: ['analytics', 'metrics', 'insights', 'performance', 'stats'],
      shortcut: 'A'
    },
    {
      id: 'nav-reporting',
      title: 'Advanced Reporting',
      subtitle: 'Generate detailed reports',
      icon: BarChart3,
      action: () => { navigate('/reporting'); onClose(); },
      category: 'navigation',
      keywords: ['reporting', 'reports', 'export', 'data', 'analysis']
    },
    {
      id: 'nav-security',
      title: 'Security & Compliance',
      subtitle: 'Manage security settings',
      icon: Shield,
      action: () => { navigate('/security'); onClose(); },
      category: 'navigation',
      keywords: ['security', 'compliance', 'privacy', 'encryption', 'audit']
    },
    {
      id: 'nav-workflows',
      title: 'Workflow Automation',
      subtitle: 'Set up automated workflows',
      icon: Rocket,
      action: () => { navigate('/workflows'); onClose(); },
      category: 'navigation',
      keywords: ['workflows', 'automation', 'triggers', 'actions', 'efficiency']
    },
    {
      id: 'nav-integrations',
      title: 'Integrations',
      subtitle: 'Connect external services',
      icon: Brain,
      action: () => { navigate('/integrations'); onClose(); },
      category: 'navigation',
      keywords: ['integrations', 'apis', 'connect', 'services', 'marketplace']
    },
    {
      id: 'nav-white-label',
      title: 'White Label',
      subtitle: 'Customize branding',
      icon: Settings,
      action: () => { navigate('/white-label'); onClose(); },
      category: 'navigation',
      keywords: ['white label', 'branding', 'customize', 'theme', 'logo']
    },
    {
      id: 'nav-mobile',
      title: 'Mobile Settings',
      subtitle: 'Configure mobile experience',
      icon: Phone,
      action: () => { navigate('/mobile'); onClose(); },
      category: 'navigation',
      keywords: ['mobile', 'responsive', 'phone', 'tablet', 'pwa']
    },
    {
      id: 'nav-ai-comparison',
      title: 'AI Platform Comparison',
      subtitle: 'Compare AI development platforms',
      icon: Brain,
      action: () => { navigate('/ai-comparison'); onClose(); },
      category: 'navigation',
      keywords: ['ai', 'comparison', 'platforms', 'benchmark', 'evaluate']
    },
    {
      id: 'nav-deployment',
      title: 'Deployment Guide',
      subtitle: 'Learn deployment strategies',
      icon: GitBranch,
      action: () => { navigate('/deployment'); onClose(); },
      category: 'navigation',
      keywords: ['deployment', 'deploy', 'guide', 'publish', 'launch']
    },
    {
      id: 'nav-help',
      title: 'Help & Documentation',
      subtitle: 'Get support and learn features',
      icon: HelpCircle,
      action: () => { navigate('/help'); onClose(); },
      category: 'navigation',
      keywords: ['help', 'documentation', 'support', 'guide', 'tutorial']
    },
    {
      id: 'nav-tokens',
      title: 'API Tokens',
      subtitle: 'Manage API credentials',
      icon: Key,
      action: () => { navigate('/tokens'); onClose(); },
      category: 'navigation',
      keywords: ['tokens', 'api', 'credentials', 'keys', 'authentication']
    },
    {
      id: 'nav-settings',
      title: 'Settings',
      subtitle: 'Configure your preferences',
      icon: Settings,
      action: () => { navigate('/settings'); onClose(); },
      category: 'navigation',
      keywords: ['settings', 'preferences', 'configuration', 'account', 'profile']
    }
  ];

  // Action commands
  const actionCommands: CommandItem[] = [
    {
      id: 'action-new-project',
      title: 'Create New Project',
      subtitle: 'Start a new AI development project',
      icon: Plus,
      action: () => { navigate('/projects?action=add'); onClose(); },
      category: 'actions',
      keywords: ['create', 'new', 'project', 'add', 'start'],
      shortcut: 'N'
    },
    {
      id: 'action-import-projects',
      title: 'Import Projects',
      subtitle: 'Import projects from CSV or other sources',
      icon: Upload,
      action: () => { 
        navigate('/projects'); 
        onClose(); 
        // Trigger import modal
        setTimeout(() => {
          const importBtn = document.querySelector('[data-action="import"]') as HTMLElement;
          if (importBtn) importBtn.click();
        }, 100);
      },
      category: 'actions',
      keywords: ['import', 'upload', 'csv', 'migrate', 'transfer']
    },
    {
      id: 'action-export-data',
      title: 'Export Data',
      subtitle: 'Download your data as CSV or JSON',
      icon: Upload,
      action: () => {
        // Trigger export functionality
        const link = document.createElement('a');
        link.href = '/api/export';
        link.download = 'devtracker-export.json';
        link.click();
        onClose();
      },
      category: 'actions',
      keywords: ['export', 'download', 'backup', 'data', 'csv', 'json']
    },
    {
      id: 'action-refresh-data',
      title: 'Refresh Data',
      subtitle: 'Reload all project data',
      icon: BarChart3,
      action: () => { window.location.reload(); onClose(); },
      category: 'actions',
      keywords: ['refresh', 'reload', 'update', 'sync', 'fetch']
    }
  ];

  // Project commands (dynamic based on projects)
  const projectCommands: CommandItem[] = projects.slice(0, 10).map((project, index) => {
    const platformIcon = project.ai_platform === 'mocha' ? Brain :
                        project.ai_platform === 'lovable' ? Heart :
                        project.ai_platform === 'bolt' ? Zap :
                        project.ai_platform === 'cursor' ? Edit :
                        project.ai_platform === 'claude' ? Brain :
                        Database;

    return {
      id: `project-${project.id}`,
      title: project.project_name,
      subtitle: `${project.ai_platform} • ${project.completion_percentage}% complete`,
      icon: platformIcon,
      action: () => { navigate(`/projects?edit=${project.id}`); onClose(); },
      category: 'projects',
      keywords: [
        project.project_name.toLowerCase(),
        project.ai_platform,
        project.project_type,
        'project',
        'edit'
      ],
      shortcut: (index + 1).toString()
    };
  });

  // Help commands
  const helpCommands: CommandItem[] = [
    {
      id: 'help-keyboard-shortcuts',
      title: 'Keyboard Shortcuts',
      subtitle: 'Learn all keyboard shortcuts',
      icon: Keyboard,
      action: () => {
        alert(`Keyboard Shortcuts:
        
⌘/Ctrl + K - Open command palette
⌘/Ctrl + D - Go to Dashboard  
⌘/Ctrl + P - Go to Projects
⌘/Ctrl + A - Go to Analytics
⌘/Ctrl + N - Create new project
⌘/Ctrl + / - Toggle help
Esc - Close modals/palette
        
Navigate palette with ↑↓ arrows, Enter to select`);
        onClose();
      },
      category: 'help',
      keywords: ['keyboard', 'shortcuts', 'hotkeys', 'commands', 'help']
    },
    {
      id: 'help-whats-new',
      title: "What's New",
      subtitle: 'See latest features and updates',
      icon: Star,
      action: () => {
        alert(`🎉 What's New in DevTracker Pro:

✨ Command Palette - Quick navigation (Ctrl+K)
🎨 Dark Mode Support - Toggle themes
🔍 Advanced Search - Filter across all data
📊 Real-time Analytics - Live project insights  
🚀 Auto-deployment Detection - Smart deployment tracking
⭐ Project Rating System - Rate platforms and projects
📈 Smart Budget Tracking - Credit usage optimization
🔄 Version History Tracking - Multi-platform versioning
🎯 AI Prompt Library - Reusable prompt templates
🌐 Comprehensive Integrations - 30+ platform connections

More features coming soon!`);
        onClose();
      },
      category: 'help',
      keywords: ['new', 'features', 'updates', 'changelog', 'release']
    },
    {
      id: 'help-support',
      title: 'Contact Support',
      subtitle: 'Get help from our team',
      icon: MessageSquare,
      action: () => {
        window.open('mailto:support@devtracker.pro?subject=DevTracker Pro Support Request', '_blank');
        onClose();
      },
      category: 'help',
      keywords: ['support', 'contact', 'help', 'email', 'assistance']
    }
  ];

  // Combine all commands
  const allCommands = [
    ...navigationCommands,
    ...actionCommands,
    ...projectCommands,
    ...helpCommands
  ];

  // Filter commands based on query
  const filteredCommands = useMemo(() => {
    if (!query.trim()) {
      // Show recent commands and top navigation when no query
      return [
        ...navigationCommands.slice(0, 4),
        ...actionCommands.slice(0, 2),
        ...projectCommands.slice(0, 3),
        ...helpCommands.slice(0, 1)
      ];
    }

    const lowerQuery = query.toLowerCase();
    return allCommands
      .filter(cmd => 
        cmd.title.toLowerCase().includes(lowerQuery) ||
        cmd.subtitle?.toLowerCase().includes(lowerQuery) ||
        cmd.keywords.some(keyword => keyword.includes(lowerQuery))
      )
      .sort((a, b) => {
        // Prioritize exact title matches
        const aExact = a.title.toLowerCase().startsWith(lowerQuery) ? 0 : 1;
        const bExact = b.title.toLowerCase().startsWith(lowerQuery) ? 0 : 1;
        if (aExact !== bExact) return aExact - bExact;
        
        // Then by category priority
        const categoryPriority = { navigation: 0, actions: 1, projects: 2, recent: 3, help: 4 };
        return categoryPriority[a.category] - categoryPriority[b.category];
      })
      .slice(0, 8); // Limit results
  }, [query, allCommands]);

  // Reset selection when filtered commands change
  useEffect(() => {
    setSelectedIndex(0);
  }, [filteredCommands]);

  // Focus input when opened
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          setSelectedIndex(prev => Math.min(prev + 1, filteredCommands.length - 1));
          break;
        case 'ArrowUp':
          e.preventDefault();
          setSelectedIndex(prev => Math.max(prev - 1, 0));
          break;
        case 'Enter':
          e.preventDefault();
          if (filteredCommands[selectedIndex]) {
            filteredCommands[selectedIndex].action();
          }
          break;
        case 'Escape':
          e.preventDefault();
          onClose();
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filteredCommands, selectedIndex, onClose]);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'navigation': return Hash;
      case 'actions': return Zap;
      case 'projects': return Database;
      case 'recent': return Clock;
      case 'help': return HelpCircle;
      default: return Hash;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'navigation': return 'text-blue-600';
      case 'actions': return 'text-green-600';
      case 'projects': return 'text-purple-600';
      case 'recent': return 'text-orange-600';
      case 'help': return 'text-gray-600';
      default: return 'text-gray-600';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black bg-opacity-50 pt-16 px-4">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center px-4 py-3 border-b border-gray-200">
          <Search className="w-5 h-5 text-gray-400 mr-3" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Type a command or search..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 text-lg placeholder-gray-500 border-none outline-none"
          />
          <div className="flex items-center space-x-2 text-xs text-gray-500">
            <kbd className="px-2 py-1 bg-gray-100 rounded">↑↓</kbd>
            <span>navigate</span>
            <kbd className="px-2 py-1 bg-gray-100 rounded">↵</kbd>
            <span>select</span>
            <kbd className="px-2 py-1 bg-gray-100 rounded">esc</kbd>
            <span>close</span>
          </div>
        </div>

        {/* Results */}
        <div className="max-h-96 overflow-y-auto">
          {filteredCommands.length === 0 ? (
            <div className="px-4 py-8 text-center text-gray-500">
              <Search className="w-8 h-8 mx-auto mb-2 text-gray-300" />
              <p>No commands found</p>
              <p className="text-sm">Try searching for "dashboard", "projects", or "new"</p>
            </div>
          ) : (
            <div className="py-2">
              {filteredCommands.map((command, index) => {
                const Icon = command.icon;
                const CategoryIcon = getCategoryIcon(command.category);
                const isSelected = index === selectedIndex;

                return (
                  <button
                    key={command.id}
                    onClick={command.action}
                    className={`w-full px-4 py-3 flex items-center space-x-3 hover:bg-gray-50 transition-colors ${
                      isSelected ? 'bg-purple-50 border-r-2 border-purple-500' : ''
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      isSelected ? 'bg-purple-100 text-purple-600' : 'bg-gray-100 text-gray-600'
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    
                    <div className="flex-1 text-left">
                      <div className="flex items-center space-x-2">
                        <span className={`font-medium ${isSelected ? 'text-purple-900' : 'text-gray-900'}`}>
                          {command.title}
                        </span>
                        <CategoryIcon className={`w-3 h-3 ${getCategoryColor(command.category)}`} />
                      </div>
                      {command.subtitle && (
                        <p className="text-sm text-gray-500 mt-0.5">{command.subtitle}</p>
                      )}
                    </div>

                    <div className="flex items-center space-x-2">
                      {command.shortcut && (
                        <kbd className="px-2 py-1 text-xs bg-gray-100 rounded border">
                          {command.shortcut}
                        </kbd>
                      )}
                      <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-purple-400' : 'text-gray-300'}`} />
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2 bg-gray-50 border-t border-gray-200 flex items-center justify-between text-xs text-gray-500">
          <div className="flex items-center space-x-1">
            <Command className="w-3 h-3" />
            <span>Command Palette</span>
          </div>
          <div>
            {filteredCommands.length} {filteredCommands.length === 1 ? 'result' : 'results'}
          </div>
        </div>
      </div>
    </div>
  );
}
