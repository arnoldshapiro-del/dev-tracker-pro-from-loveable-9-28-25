
ALTER TABLE user_preferences DROP COLUMN github_token;
ALTER TABLE user_preferences DROP COLUMN netlify_token;
