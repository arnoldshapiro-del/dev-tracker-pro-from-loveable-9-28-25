# DevTracker Pro - Complete Technical Documentation

## Executive Summary

DevTracker Pro is a comprehensive AI development project management system built as part of a unified healthcare/development application. It provides advanced project tracking, budget management, deployment monitoring, and cross-platform comparison capabilities for AI development projects.

---

## 1. Application Architecture

### 1.1 System Overview
- **Architecture**: Single-page application with dual-mode functionality
- **Primary Mode**: DevTracker Pro (AI Development Manager)
- **Secondary Mode**: ReminderPro (Healthcare Provider)
- **Mode Switching**: Real-time toggle between medical and development interfaces

### 1.2 Technology Stack

#### Frontend Technologies
```json
{
  "framework": "React 19.0.0",
  "language": "TypeScript 5.8.3",
  "styling": "Tailwind CSS 3.4.17",
  "icons": "Lucide React 0.510.0",
  "routing": "React Router 7.5.3",
  "charts": "Recharts 3.1.0",
  "drag_drop": "@dnd-kit/core 6.3.1",
  "build_tool": "Vite 7.1.3"
}
```

#### Backend Technologies
```json
{
  "framework": "Hono 4.7.7",
  "runtime": "Cloudflare Workers",
  "database": "Cloudflare D1 (SQLite-based)",
  "authentication": "@getmocha/users-service 0.0.4",
  "validation": "Zod 3.24.3"
}
```

### 1.3 Project Structure
```
src/
├── react-app/
│   ├── components/          # Reusable UI components
│   ├── pages/              # Route-based page components
│   ├── hooks/              # Custom React hooks
│   └── utils/              # Utility functions
├── worker/                 # Backend API endpoints
├── shared/                 # Shared types and utilities
└── vite-env.d.ts          # TypeScript environment definitions
```

---

## 2. Database Schema (DevTracker Pro Tables)

### 2.1 Core Project Management

#### `projects` Table
```sql
CREATE TABLE projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  project_name TEXT NOT NULL,
  project_description TEXT,
  ai_platform TEXT NOT NULL,
  project_type TEXT NOT NULL,
  status TEXT DEFAULT 'planning',
  completion_percentage INTEGER DEFAULT 0,
  current_version TEXT DEFAULT '1.0.0',
  
  -- URLs and Platform Integration
  github_repo_url TEXT,
  netlify_url TEXT,
  vercel_url TEXT,
  platform_url TEXT,
  
  -- Budget and Credits
  credits_used INTEGER DEFAULT 0,
  initial_budget_credits INTEGER DEFAULT 100,
  credits_remaining INTEGER DEFAULT 100,
  estimated_completion_credits INTEGER DEFAULT 0,
  cost_per_feature REAL DEFAULT 0,
  budget_efficiency_score REAL DEFAULT 0,
  
  -- Performance Metrics
  time_to_deploy_hours REAL DEFAULT 0,
  build_success_rate REAL DEFAULT 100.0,
  deployment_success_rate REAL DEFAULT 100.0,
  
  -- Development Tracking
  features_completed TEXT, -- JSON array
  features_pending TEXT,   -- JSON array
  known_bugs TEXT,        -- JSON array
  
  -- Version Control Integration
  mocha_published_url TEXT,
  mocha_published_at DATETIME,
  mocha_published_version TEXT DEFAULT 'v1.0.0',
  mocha_development_url TEXT,
  mocha_development_updated_at DATETIME,
  
  github_pushed_at DATETIME,
  github_commit_hash TEXT,
  github_branch TEXT DEFAULT 'main',
  github_development_url TEXT,
  github_development_updated_at DATETIME,
  
  netlify_deployed_at DATETIME,
  netlify_deploy_id TEXT,
  netlify_domain TEXT,
  netlify_development_url TEXT,
  netlify_development_updated_at DATETIME,
  
  vercel_deployed_at DATETIME,
  vercel_deployment_id TEXT,
  vercel_development_url TEXT,
  vercel_development_updated_at DATETIME,
  
  -- Custom Platforms (3 slots)
  custom_platform_1_name TEXT,
  custom_platform_1_url TEXT,
  custom_platform_1_deployed_at DATETIME,
  custom_platform_1_version TEXT,
  custom_platform_1_development_url TEXT,
  custom_platform_1_development_updated_at DATETIME,
  
  -- Additional integrations
  twilio_configured_at DATETIME,
  twilio_phone_number TEXT,
  twilio_status TEXT DEFAULT 'not_configured',
  twilio_development_url TEXT,
  twilio_development_updated_at DATETIME,
  
  -- Metadata
  is_published BOOLEAN DEFAULT 0,
  contains_sensitive_data BOOLEAN DEFAULT 0,
  privacy_notes TEXT,
  last_successful_build DATETIME,
  last_successful_deployment DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 2.2 AI Platform Management

#### `ai_assistants` Table
```sql
CREATE TABLE ai_assistants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  platform_name TEXT NOT NULL,     -- 'mocha', 'lovable', 'bolt', etc.
  platform_url TEXT NOT NULL,
  pricing_model TEXT NOT NULL,     -- 'free', 'credits', 'subscription'
  credits_remaining INTEGER,
  subscription_status TEXT,        -- 'active', 'expired', 'trial'
  projects_completed INTEGER DEFAULT 0,
  average_completion_time_hours REAL DEFAULT 0,
  success_rate_percentage REAL DEFAULT 100.0,
  credit_efficiency_score REAL DEFAULT 0,
  best_for TEXT,                   -- JSON array of project types
  worst_for TEXT,                  -- JSON array of project types
  notes TEXT,
  last_used_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 2.3 Project Analytics and Tracking

#### `project_version_logs` Table
```sql
CREATE TABLE project_version_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  platform_name TEXT NOT NULL,    -- 'mocha', 'github', 'netlify', etc.
  action_type TEXT NOT NULL,       -- 'publish', 'push', 'deploy', 'configure'
  version_number TEXT,
  platform_url TEXT,
  commit_hash TEXT,
  deployment_id TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

#### `ai_prompts` Table
```sql
CREATE TABLE ai_prompts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  prompt_title TEXT NOT NULL,
  prompt_content TEXT NOT NULL,
  prompt_version TEXT DEFAULT 'v1.0',
  ai_platform TEXT NOT NULL,
  success_rating INTEGER DEFAULT 5,    -- 1-10 scale
  output_quality INTEGER DEFAULT 5,    -- 1-10 scale
  time_to_result_minutes INTEGER,
  credits_consumed INTEGER DEFAULT 0,
  tags TEXT,                           -- JSON array
  is_favorite BOOLEAN DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2.4 Budget and Performance Tracking

#### `project_budgets` Table
```sql
CREATE TABLE project_budgets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  initial_budget_credits INTEGER NOT NULL,
  current_credits_remaining INTEGER NOT NULL,
  credits_consumed INTEGER DEFAULT 0,
  estimated_completion_credits INTEGER,
  budget_alerts_enabled BOOLEAN DEFAULT 1,
  alert_threshold_percentage INTEGER DEFAULT 80,
  cost_per_feature REAL DEFAULT 0,
  efficiency_score REAL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### `credit_usage` Table
```sql
CREATE TABLE credit_usage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  platform_name TEXT NOT NULL,
  credits_used INTEGER NOT NULL,
  task_description TEXT NOT NULL,
  efficiency_rating INTEGER DEFAULT 5,  -- 1-10 scale
  was_successful BOOLEAN DEFAULT 1,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 2.5 Cross-Platform Analysis

#### `cross_platform_comparisons` Table
```sql
CREATE TABLE cross_platform_comparisons (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  project_concept TEXT NOT NULL,
  platform_results TEXT NOT NULL,     -- JSON object with platform results
  winner_platform TEXT,
  cost_analysis TEXT,                 -- JSON object
  time_analysis TEXT,                 -- JSON object
  quality_analysis TEXT,              -- JSON object
  recommendation_notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 3. User Interface Components

### 3.1 Main Navigation Structure

#### Desktop Sidebar Navigation
```typescript
const devNavigation = [
  { name: 'Dashboard', href: '/dashboard', icon: BarChart3 },
  { name: 'Projects', href: '/projects', icon: Folder },
  { name: 'Analytics', href: '/analytics', icon: TrendingUp },
  { name: 'AI Assistants', href: '/ai-assistants', icon: Code2 },
  { name: 'Team', href: '/team', icon: Users },
  { name: 'Deployment', href: '/deployment', icon: Zap },
  { name: 'Settings', href: '/settings', icon: Settings },
  { name: 'Help', href: '/help', icon: HelpCircle },
];
```

#### Mode Switcher Component
- Toggle between ReminderPro and DevTracker Pro modes
- Real-time interface transformation
- Persistent mode selection via localStorage
- Visual indicators for current mode

### 3.2 Core DevTracker Pro Pages

#### 3.2.1 Projects Page (`/projects`)
**File**: `src/react-app/pages/Projects.tsx`

**Features**:
- Drag & drop project reordering using @dnd-kit
- Advanced search and filtering with 15+ criteria
- Real-time project status updates
- Multi-platform URL management with health checking
- Interactive project cards with quick actions
- 14 specialized tabs for different workflows

**Tab Navigation**:
1. **Projects**: Main project grid with drag & drop
2. **Export & Import**: Project data migration tools
3. **Comprehensive Ratings**: Professional rating system with timestamped reviews
4. **Version History**: Cross-platform version tracking
5. **Smart Budget**: AI-powered budget analysis and predictions
6. **Smart Credits**: Advanced credit usage analytics
7. **Auto Deploy (Fake)**: Simulated deployment automation
8. **Real Auto Deploy**: Actual deployment automation
9. **AI Prompts**: Prompt library and management
10. **Deploy Status**: Live deployment monitoring
11. **Platform Compare**: Cross-platform benchmarking
12. **Templates**: Project template marketplace
13. **Time Tracker**: Development time analytics
14. **Timeline**: Visual project timeline

#### 3.2.2 Dashboard Page (`/dashboard`)
**File**: `src/react-app/pages/Dashboard.tsx`

**Features**:
- Real-time stats cards with gradient backgrounds
- Quick action buttons for common tasks
- Recent activity feed
- Performance metrics visualization
- Cross-mode compatibility (medical/development)

#### 3.2.3 Analytics Page (`/analytics`)
**File**: `src/react-app/pages/Analytics.tsx`

**Features**:
- Interactive charts using Recharts library
- Multiple visualization types (bar, pie, line charts)
- Time range filtering (7d, 30d, 90d, 1y)
- Export functionality
- Performance insights and recommendations

### 3.3 Specialized Components

#### 3.3.1 Advanced Search Component
**File**: `src/react-app/components/AdvancedSearch.tsx`

**Search Fields**:
```typescript
export const projectSearchFields = [
  'project_name',
  'project_description', 
  'ai_platform',
  'project_type',
  'status',
  'features_completed',
  'features_pending',
  'known_bugs',
  'github_repo_url',
  'netlify_url'
];
```

**Filter Capabilities**:
- AI Platform filtering (15+ platforms)
- Project status filtering
- Completion percentage ranges
- Credit usage ranges
- Date range filtering
- Custom tag filtering

#### 3.3.2 Project Cards with Enhanced Features
**Features**:
- Drag handle for reordering
- Status badges with color coding
- Progress bars with gradient animations
- Feature completion metrics
- Budget usage indicators
- Platform status indicators with clickable links
- Quick action buttons
- Version status badges

#### 3.3.3 URL Management System
**Smart URL Input Component**:
- Real-time URL validation
- External link buttons
- Platform-specific styling
- Timestamp tracking
- Health status monitoring

---

## 4. API Endpoints and Data Flow

### 4.1 Core Project Endpoints

#### GET `/api/projects`
```typescript
// Fetch user's projects with optional filtering
Parameters: {
  limit?: string,
  sort?: string,  // Default: 'updated_at'
  order?: 'asc' | 'desc'
}
Response: ProjectType[]
```

#### POST `/api/projects`
```typescript
// Create new project
Body: {
  project_name: string,
  project_description?: string,
  ai_platform: string,
  project_type: string,
  platform_url?: string,
  github_repo_url?: string,
  netlify_url?: string,
  credits_used?: number
}
Response: { id: number, ...projectData }
```

#### PUT `/api/projects/:id`
```typescript
// Update project with comprehensive version tracking
Body: Partial<ProjectType>
Features:
  - Updates all project fields
  - Automatic version log creation
  - Timestamp management
  - Cross-platform URL tracking
Response: { message: "Project updated successfully" }
```

#### DELETE `/api/projects/:id`
```typescript
// Delete project with user verification
Response: { message: "Project deleted successfully" }
```

### 4.2 Analytics and Reporting Endpoints

#### GET `/api/dashboard/stats`
```typescript
// Comprehensive dashboard statistics
Response: {
  totalProjects: number,
  activeProjects: number,
  deployedProjects: number,
  totalCreditsUsed: number,
  averageProjectCompletion: number,
  mostUsedPlatform: string,
  projectsNeedingAttention: number,
  recentActivity: ActivityItem[]
}
```

#### GET `/api/projects/:id/version-logs`
```typescript
// Project version history
Response: VersionLogEntry[]
```

#### POST `/api/projects/:id/version-logs`
```typescript
// Manual version log entry
Body: {
  platform_name: string,
  action_type: string,
  version_number?: string,
  platform_url?: string,
  notes?: string
}
```

### 4.3 AI Platform Management

#### GET `/api/ai-assistants`
```typescript
// User's AI assistant configurations
Response: AIAssistantType[]
```

#### GET `/api/credit-usage`
```typescript
// Credit usage analytics
Response: CreditUsageType[]
```

---

## 5. Supported AI Platforms

### 5.1 Integrated Platforms
```typescript
const AI_PLATFORMS = [
  { id: 'mocha', name: 'Mocha', color: 'blue', icon: Brain },
  { id: 'lovable', name: 'Lovable', color: 'pink', icon: Heart },
  { id: 'bolt', name: 'Bolt', color: 'yellow', icon: Zap },
  { id: 'emergent', name: 'Emergent', color: 'indigo', icon: Zap },
  { id: 'genspark', name: 'GenSpark', color: 'red', icon: Zap },
  { id: 'google-opal', name: 'Google Opal', color: 'teal', icon: Brain },
  { id: 'google-gemini', name: 'Google Gemini', color: 'purple', icon: Brain },
  { id: 'chatgpt-5', name: 'ChatGPT 5', color: 'green', icon: Brain },
  { id: 'cursor', name: 'Cursor', color: 'slate', icon: Edit },
  { id: 'claude', name: 'Claude', color: 'orange', icon: Brain },
  { id: 'replit', name: 'Replit', color: 'cyan', icon: Database },
  { id: 'abacus-ai', name: 'Abacus AI', color: 'violet', icon: Brain },
  { id: 'manus', name: 'Manus', color: 'emerald', icon: Brain },
  { id: 'minimax', name: 'Minimax', color: 'rose', icon: Brain },
  { id: 'custom', name: 'Add Custom Platform', color: 'gray', icon: Plus }
];
```

### 5.2 Platform Integration Features
- **URL Tracking**: Development and production URLs for each platform
- **Version Control**: Automated version logging across platforms
- **Deployment Status**: Real-time deployment monitoring
- **Credit Tracking**: Platform-specific credit usage monitoring
- **Performance Metrics**: Platform comparison and efficiency scoring

---

## 6. Deployment and Infrastructure

### 6.1 Deployment Platforms
```typescript
// Supported deployment platforms
const DEPLOYMENT_PLATFORMS = {
  mocha: {
    development_url_pattern: "https://getmocha.com/apps/{id}?chat=open",
    production_url_pattern: "https://{subdomain}.mocha.app"
  },
  github: {
    development_url_pattern: "https://github.com/{user}/{repo}/tree/{branch}",
    production_url_pattern: "https://github.com/{user}/{repo}"
  },
  netlify: {
    development_url_pattern: "https://app.netlify.com/sites/{site}",
    production_url_pattern: "https://{domain}.netlify.app"
  },
  vercel: {
    development_url_pattern: "https://vercel.com/{user}/{project}",
    production_url_pattern: "https://{domain}.vercel.app"
  }
};
```

### 6.2 Environment Configuration
```typescript
interface Environment {
  MOCHA_USERS_SERVICE_API_KEY: string,
  MOCHA_USERS_SERVICE_API_URL: string,
  GITHUB_PERSONAL_ACCESS_TOKEN?: string,
  NETLIFY_PERSONAL_ACCESS_TOKEN?: string,
  TWILIO_ACCOUNT_SID?: string,
  TWILIO_AUTH_TOKEN?: string,
  TWILIO_PHONE_NUMBER?: string,
  DB: D1Database
}
```

---

## 7. Key Features and Workflows

### 7.1 Project Creation Workflow
1. **Project Setup**: Basic information entry with AI platform selection
2. **Platform Integration**: URL configuration for all deployment platforms
3. **Budget Configuration**: Credit allocation and budget tracking setup
4. **Version Control**: Initial version tracking configuration
5. **Feature Planning**: Feature roadmap and milestone setup

### 7.2 Development Tracking Workflow
1. **Progress Updates**: Real-time completion percentage tracking
2. **Feature Management**: Completed/pending feature tracking with JSON arrays
3. **Bug Tracking**: Issue logging with priority and status management
4. **Version Logging**: Automatic and manual version history tracking
5. **Deployment Monitoring**: Cross-platform deployment status tracking

### 7.3 Budget Management Workflow
1. **Credit Allocation**: Initial budget setup with platform distribution
2. **Usage Tracking**: Real-time credit consumption monitoring
3. **Efficiency Analysis**: Cost-per-feature calculations and efficiency scoring
4. **Budget Alerts**: Automated warnings at configurable thresholds
5. **Optimization Recommendations**: AI-powered budget optimization suggestions

### 7.4 Cross-Platform Comparison Workflow
1. **Project Concept Definition**: Core project requirements specification
2. **Platform Testing**: Parallel development across multiple AI platforms
3. **Metrics Collection**: Performance, cost, and quality metrics gathering
4. **Analysis Generation**: Automated comparison reports with recommendations
5. **Decision Documentation**: Final platform selection with reasoning

---

## 8. Data Validation and Business Logic

### 8.1 Project Validation Rules
```typescript
const projectValidationSchema = z.object({
  project_name: z.string().min(1).max(255),
  project_description: z.string().optional(),
  ai_platform: z.string().min(1),
  project_type: z.enum(['medical', 'ecommerce', 'saas', 'web', 'mobile', 'ai', 'other']),
  completion_percentage: z.number().min(0).max(100),
  credits_used: z.number().min(0),
  github_repo_url: z.string().url().optional(),
  netlify_url: z.string().url().optional(),
  vercel_url: z.string().url().optional()
});
```

### 8.2 Status Management
```typescript
const STATUS_COLORS = {
  planning: 'bg-gray-100 text-gray-800',
  development: 'bg-blue-100 text-blue-800',
  testing: 'bg-yellow-100 text-yellow-800',
  deployed: 'bg-green-100 text-green-800',
  maintenance: 'bg-purple-100 text-purple-800',
  abandoned: 'bg-red-100 text-red-800'
};
```

### 8.3 Credit Management Logic
- **Budget Calculation**: `credits_remaining = initial_budget_credits - credits_used`
- **Efficiency Scoring**: `efficiency_score = features_completed / credits_used`
- **Alert Triggers**: Warnings at 80% budget consumption (configurable)
- **Predictive Analysis**: Estimated completion cost based on current trajectory

---

## 9. Import/Export Capabilities

### 9.1 Supported Data Formats
- **CSV Import/Export**: Full project data with comprehensive field mapping
- **JSON Export**: Complete project structure with metadata
- **Template Export**: Reusable project templates with anonymized data

### 9.2 Migration Tools
```typescript
interface ProjectMigrationData {
  projects: ProjectType[],
  ai_assistants: AIAssistantType[],
  version_logs: VersionLogEntry[],
  budget_data: ProjectBudgetType[],
  credit_usage: CreditUsageType[]
}
```

---

## 10. Security and Privacy

### 10.1 Data Protection
- **User Isolation**: All data filtered by authenticated user ID
- **Sensitive Data Flags**: Optional marking of projects containing sensitive information
- **Privacy Notes**: Custom privacy annotations per project
- **Access Controls**: Role-based permissions for team collaboration

### 10.2 Authentication Flow
```typescript
// Authentication middleware ensures all API calls are authenticated
app.use('/api/*', authMiddleware);

// User context injection
const user: AuthenticatedUser = c.get("user");
```

---

## 11. Performance Optimizations

### 11.1 Database Optimizations
- **Indexing**: Strategic indexes on frequently queried fields
- **Pagination**: Built-in limit/offset support for large datasets
- **Lazy Loading**: On-demand data fetching for improved performance
- **Caching**: LocalStorage caching for user preferences and UI state

### 11.2 Frontend Optimizations
- **Code Splitting**: Route-based code splitting with React.lazy
- **Memoization**: React.memo and useMemo for expensive computations
- **Virtual Scrolling**: Efficient rendering of large project lists
- **Optimistic Updates**: Immediate UI updates with server reconciliation

---

## 12. Monitoring and Analytics

### 12.1 Application Metrics
- **Project Completion Rates**: Success rate tracking across platforms
- **Credit Efficiency**: Platform comparison and optimization recommendations
- **Deployment Success**: Build and deployment success rate monitoring
- **User Engagement**: Feature usage analytics and optimization insights

### 12.2 Real-time Monitoring
```typescript
interface PerformanceMetrics {
  time_to_deploy_hours: number,
  features_completed: number,
  bugs_fixed: number,
  code_quality_score: number,
  user_satisfaction_score: number,
  credits_efficiency: number
}
```

---

## 13. Sample Data Examples

### 13.1 Sample Project Record
```json
{
  "id": 1,
  "user_id": "user_123",
  "project_name": "Healthcare AI Assistant",
  "project_description": "AI-powered patient reminder system with smart scheduling",
  "ai_platform": "mocha",
  "project_type": "medical",
  "status": "development",
  "completion_percentage": 75,
  "credits_used": 85,
  "initial_budget_credits": 100,
  "credits_remaining": 15,
  "time_to_deploy_hours": 12.5,
  "features_completed": "[\"User Authentication\", \"Patient Management\", \"SMS Reminders\"]",
  "features_pending": "[\"Email Integration\", \"Analytics Dashboard\"]",
  "known_bugs": "[\"Timezone handling issue\", \"Mobile layout bug\"]",
  "github_repo_url": "https://github.com/user/healthcare-ai",
  "netlify_url": "https://healthcare-ai.netlify.app",
  "mocha_published_url": "https://abc123.mocha.app",
  "mocha_published_at": "2024-01-15T10:30:00Z",
  "github_pushed_at": "2024-01-15T14:22:00Z",
  "netlify_deployed_at": "2024-01-15T14:45:00Z",
  "build_success_rate": 95.5,
  "deployment_success_rate": 98.2,
  "created_at": "2024-01-01T09:00:00Z",
  "updated_at": "2024-01-15T15:00:00Z"
}
```

### 13.2 Sample AI Assistant Configuration
```json
{
  "id": 1,
  "user_id": "user_123",
  "platform_name": "Mocha",
  "platform_url": "https://getmocha.com",
  "pricing_model": "credits",
  "credits_remaining": 150,
  "subscription_status": "active",
  "projects_completed": 12,
  "average_completion_time_hours": 8.5,
  "success_rate_percentage": 92.3,
  "credit_efficiency_score": 4.2,
  "best_for": "[\"Medical Apps\", \"Data Visualization\", \"User Interfaces\"]",
  "worst_for": "[\"Complex Backend Logic\", \"Real-time Features\"]",
  "notes": "Excellent for rapid prototyping and UI-heavy applications",
  "last_used_at": "2024-01-15T12:00:00Z"
}
```

---

## 14. Development Setup and Configuration

### 14.1 Local Development
```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Type checking
npm run check

# Build for production
npm run build
```

### 14.2 Environment Variables
```env
MOCHA_USERS_SERVICE_API_KEY=your_api_key
MOCHA_USERS_SERVICE_API_URL=https://api.getmocha.com
GITHUB_PERSONAL_ACCESS_TOKEN=optional_github_token
NETLIFY_PERSONAL_ACCESS_TOKEN=optional_netlify_token
```

### 14.3 Database Migrations
The application uses Cloudflare D1 with automatic schema management. All tables are created with proper indexes and relationships as defined in the schema section.

---

## 15. Customization and Extension Points

### 15.1 Adding New AI Platforms
```typescript
// Add to AI_PLATFORMS array in Projects.tsx
{
  id: 'new-platform',
  name: 'New Platform',
  color: 'brand-color',
  icon: PlatformIcon,
  rating: 0
}
```

### 15.2 Custom Project Types
```typescript
// Extend project_type enum in validation schema
project_type: z.enum([
  'medical', 'ecommerce', 'saas', 'web', 
  'mobile', 'ai', 'custom-type', 'other'
])
```

### 15.3 Additional Deployment Platforms
The system supports three custom platform slots per project for extensibility:
- `custom_platform_1_*`
- `custom_platform_2_*`
- `custom_platform_3_*`

---

## 16. Backup and Data Recovery

### 16.1 Export Functionality
- **Full Export**: Complete project data with relationships
- **Selective Export**: User-defined data subsets
- **Template Creation**: Anonymized project templates for reuse

### 16.2 Import Capabilities
- **CSV Import**: Bulk project creation from spreadsheet data
- **JSON Import**: Full project restoration from exports
- **Migration Tools**: Cross-platform data migration support

---

## 17. API Rate Limits and Performance

### 17.1 Request Limits
- **API Calls**: Managed through Cloudflare Workers limits
- **Database Queries**: Optimized with prepared statements and indexing
- **File Uploads**: Handled through Cloudflare Workers with size limits

### 17.2 Caching Strategy
- **Browser Cache**: Static assets with proper cache headers
- **LocalStorage**: User preferences and UI state
- **Session Cache**: Authentication tokens and user data

---

## Conclusion

DevTracker Pro represents a comprehensive AI development project management solution with advanced features for tracking, budgeting, deployment monitoring, and cross-platform comparison. The system is built on modern web technologies with a focus on performance, security, and extensibility.

The application's dual-mode architecture allows seamless switching between healthcare and development management interfaces, making it a versatile tool for professionals working across multiple domains.

For additional technical support or customization requests, refer to the codebase documentation and API endpoint definitions provided in this specification.

---

**Document Version**: 1.0  
**Last Updated**: January 2025  
**Technology Stack**: React 19, TypeScript, Hono, Cloudflare D1  
**Application URL**: https://e37eopt4jmiui.mocha.app
