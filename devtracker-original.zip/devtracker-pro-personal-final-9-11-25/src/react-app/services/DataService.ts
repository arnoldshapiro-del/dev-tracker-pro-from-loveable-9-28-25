// Central data service for managing all application data with localStorage and JSON import/export
import type { ProjectType, AIAssistantType, DeploymentEventType } from "@/shared/types";

export interface AppData {
  projects: ProjectType[];
  aiAssistants: AIAssistantType[];
  deploymentEvents: DeploymentEventType[];
  settings: {
    githubToken?: string;
    netlifyToken?: string;
    notifications: boolean;
    theme: 'light' | 'dark';
  };
  metadata: {
    version: string;
    lastUpdated: string;
    exportedBy?: string;
  };
}

class DataService {
  private static instance: DataService;
  private data: AppData;
  private storageKey = 'devtracker-pro-data';

  private constructor() {
    this.data = this.loadData();
  }

  static getInstance(): DataService {
    if (!DataService.instance) {
      DataService.instance = new DataService();
    }
    return DataService.instance;
  }

  private getDefaultData(): AppData {
    return {
      projects: [
        {
          id: 1,
          user_id: "local-user",
          project_name: "AI Chatbot Assistant",
          project_description: "An intelligent chatbot for customer support",
          ai_platform: "OpenAI",
          project_type: "Web Application",
          status: "completed",
          completion_percentage: 100,
          current_version: "v1.0.0",
          github_repo_url: "https://github.com/example/chatbot",
          github_status: "active",
          netlify_url: "https://my-chatbot.netlify.app",
          netlify_status: "deployed",
          vercel_url: "",
          vercel_status: "inactive",
          twilio_configured: true,
          openai_configured: true,
          credits_used: 150,
          credits_remaining: 850,
          is_published: true,
          contains_sensitive_data: false,
          build_success_rate: 95,
          deployment_success_rate: 90,
          created_at: "2024-01-15T10:00:00Z",
          updated_at: "2024-02-01T10:00:00Z",
          initial_budget_credits: 1000,
          time_to_deploy_hours: 2.5
        },
        {
          id: 2,
          user_id: "local-user",
          project_name: "Task Management Dashboard",
          project_description: "A comprehensive project management tool",
          ai_platform: "Claude",
          project_type: "Web Application",
          status: "in_progress",
          completion_percentage: 75,
          current_version: "v0.8.0",
          github_repo_url: "https://github.com/example/task-manager",
          github_status: "active",
          netlify_url: "",
          netlify_status: "inactive",
          vercel_url: "",
          vercel_status: "inactive",
          twilio_configured: false,
          openai_configured: true,
          credits_used: 200,
          credits_remaining: 300,
          is_published: false,
          contains_sensitive_data: true,
          build_success_rate: 88,
          deployment_success_rate: 0,
          created_at: "2024-02-10T10:00:00Z",
          updated_at: "2024-02-20T10:00:00Z",
          initial_budget_credits: 500,
          time_to_deploy_hours: undefined
        },
        {
          id: 3,
          user_id: "local-user",
          project_name: "Weather Prediction API",
          project_description: "ML-powered weather forecasting service",
          ai_platform: "GitHub Copilot",
          project_type: "API",
          status: "planning",
          completion_percentage: 25,
          current_version: "v0.1.0",
          github_repo_url: "",
          github_status: "inactive",
          netlify_url: "",
          netlify_status: "inactive",
          vercel_url: "",
          vercel_status: "inactive",
          twilio_configured: false,
          openai_configured: false,
          credits_used: 50,
          credits_remaining: 450,
          is_published: false,
          contains_sensitive_data: false,
          build_success_rate: 0,
          deployment_success_rate: 0,
          created_at: "2024-02-25T10:00:00Z",
          updated_at: "2024-02-25T10:00:00Z",
          initial_budget_credits: 500,
          time_to_deploy_hours: undefined
        }
      ],
      aiAssistants: [
        {
          id: 1,
          user_id: "local-user",
          platform_name: "OpenAI",
          platform_url: "https://platform.openai.com",
          pricing_model: "usage_based",
          credits_remaining: 850,
          projects_completed: 1,
          average_completion_time_hours: 2.5,
          success_rate_percentage: 95,
          credit_efficiency_score: 6.67,
          best_for: '["Web Applications", "APIs", "Chatbots"]',
          worst_for: '["Mobile Apps"]',
          last_used_at: "2024-02-01T10:00:00Z",
          created_at: "2024-01-15T10:00:00Z",
          updated_at: "2024-02-01T10:00:00Z"
        },
        {
          id: 2,
          user_id: "local-user",
          platform_name: "Claude",
          platform_url: "https://claude.ai",
          pricing_model: "subscription",
          subscription_status: "active",
          projects_completed: 1,
          average_completion_time_hours: 3.2,
          success_rate_percentage: 88,
          credit_efficiency_score: 7.2,
          best_for: '["Data Analysis", "Documentation"]',
          worst_for: '["Real-time applications"]',
          last_used_at: "2024-02-20T10:00:00Z",
          created_at: "2024-02-10T10:00:00Z",
          updated_at: "2024-02-20T10:00:00Z"
        }
      ],
      deploymentEvents: [
        {
          id: 1,
          project_id: 1,
          event_type: "netlify_deploy",
          event_description: "Successfully deployed to Netlify",
          status: "success",
          platform_involved: "Netlify",
          credits_used: 5,
          created_at: "2024-02-01T10:00:00Z"
        },
        {
          id: 2,
          project_id: 2,
          event_type: "github_push",
          event_description: "Code pushed to GitHub repository",
          status: "success",
          platform_involved: "GitHub",
          created_at: "2024-02-20T10:00:00Z"
        }
      ],
      settings: {
        notifications: true,
        theme: 'light'
      },
      metadata: {
        version: "1.0.0",
        lastUpdated: new Date().toISOString()
      }
    };
  }

  private loadData(): AppData {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Ensure data structure is complete
        return {
          ...this.getDefaultData(),
          ...parsed,
          metadata: {
            ...this.getDefaultData().metadata,
            ...parsed.metadata
          }
        };
      }
    } catch (error) {
      console.error('Error loading data from localStorage:', error);
    }
    return this.getDefaultData();
  }

  private saveData(): void {
    try {
      this.data.metadata.lastUpdated = new Date().toISOString();
      localStorage.setItem(this.storageKey, JSON.stringify(this.data));
    } catch (error) {
      console.error('Error saving data to localStorage:', error);
    }
  }

  // Projects CRUD
  async getProjects(): Promise<ProjectType[]> {
    return Promise.resolve(this.data.projects);
  }

  async getProject(id: number): Promise<ProjectType | null> {
    const project = this.data.projects.find(p => p.id === id);
    return Promise.resolve(project || null);
  }

  async createProject(project: Omit<ProjectType, 'id' | 'created_at' | 'updated_at'>): Promise<ProjectType> {
    const newProject: ProjectType = {
      ...project,
      id: Math.max(0, ...this.data.projects.map(p => p.id)) + 1,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    this.data.projects.push(newProject);
    this.saveData();
    return Promise.resolve(newProject);
  }

  async updateProject(id: number, updates: Partial<ProjectType>): Promise<ProjectType | null> {
    const index = this.data.projects.findIndex(p => p.id === id);
    if (index === -1) return Promise.resolve(null);
    
    this.data.projects[index] = {
      ...this.data.projects[index],
      ...updates,
      updated_at: new Date().toISOString()
    };
    this.saveData();
    return Promise.resolve(this.data.projects[index]);
  }

  async deleteProject(id: number): Promise<boolean> {
    const index = this.data.projects.findIndex(p => p.id === id);
    if (index === -1) return Promise.resolve(false);
    
    this.data.projects.splice(index, 1);
    // Also remove related deployment events
    this.data.deploymentEvents = this.data.deploymentEvents.filter(e => e.project_id !== id);
    this.saveData();
    return Promise.resolve(true);
  }

  // AI Assistants
  async getAIAssistants(): Promise<AIAssistantType[]> {
    return Promise.resolve(this.data.aiAssistants);
  }

  // Deployment Events
  async getDeploymentEvents(): Promise<DeploymentEventType[]> {
    return Promise.resolve(this.data.deploymentEvents);
  }

  async addDeploymentEvent(event: Omit<DeploymentEventType, 'id' | 'created_at'>): Promise<DeploymentEventType> {
    const newEvent: DeploymentEventType = {
      ...event,
      id: Math.max(0, ...this.data.deploymentEvents.map(e => e.id || 0)) + 1,
      created_at: new Date().toISOString()
    };
    this.data.deploymentEvents.push(newEvent);
    this.saveData();
    return Promise.resolve(newEvent);
  }

  // Settings
  async getSettings() {
    return Promise.resolve(this.data.settings);
  }

  async updateSettings(updates: Partial<typeof this.data.settings>) {
    this.data.settings = { ...this.data.settings, ...updates };
    this.saveData();
    return Promise.resolve(this.data.settings);
  }

  // Import/Export
  exportToJSON(): string {
    const exportData = {
      ...this.data,
      metadata: {
        ...this.data.metadata,
        exportedAt: new Date().toISOString(),
        exportedBy: "DevTracker Pro User"
      }
    };
    return JSON.stringify(exportData, null, 2);
  }

  async importFromJSON(jsonString: string): Promise<{ success: boolean; message: string; imported?: any }> {
    try {
      const importedData = JSON.parse(jsonString);
      
      // Validate the data structure
      if (!importedData.projects || !Array.isArray(importedData.projects)) {
        return { success: false, message: "Invalid data format: missing or invalid projects array" };
      }

      // Backup current data
      const backup = { ...this.data };
      
      try {
        // Merge imported data with existing data
        if (importedData.projects) {
          // Update existing projects or add new ones
          importedData.projects.forEach((importedProject: ProjectType) => {
            const existingIndex = this.data.projects.findIndex(p => p.id === importedProject.id);
            if (existingIndex >= 0) {
              this.data.projects[existingIndex] = { ...importedProject, updated_at: new Date().toISOString() };
            } else {
              this.data.projects.push({ ...importedProject, updated_at: new Date().toISOString() });
            }
          });
        }

        if (importedData.aiAssistants) {
          this.data.aiAssistants = importedData.aiAssistants;
        }

        if (importedData.deploymentEvents) {
          this.data.deploymentEvents = importedData.deploymentEvents;
        }

        if (importedData.settings) {
          this.data.settings = { ...this.data.settings, ...importedData.settings };
        }

        this.saveData();
        return { 
          success: true, 
          message: `Successfully imported ${importedData.projects.length} projects and related data`,
          imported: {
            projects: importedData.projects.length,
            aiAssistants: importedData.aiAssistants?.length || 0,
            deploymentEvents: importedData.deploymentEvents?.length || 0
          }
        };
      } catch (error) {
        // Restore backup on error
        this.data = backup;
        throw error;
      }
    } catch (error) {
      console.error('Import error:', error);
      return { success: false, message: `Import failed: ${error instanceof Error ? error.message : 'Unknown error'}` };
    }
  }

  // Utility methods
  async clearAllData(): Promise<void> {
    this.data = this.getDefaultData();
    this.saveData();
  }

  getMetadata() {
    return this.data.metadata;
  }

  // Mock API methods for compatibility
  async testConnections() {
    return Promise.resolve({
      github: { connected: !!this.data.settings.githubToken, status: 'Connected' },
      netlify: { connected: !!this.data.settings.netlifyToken, status: 'Connected' }
    });
  }

  async getNotifications() {
    return Promise.resolve([
      {
        id: 1,
        message: "Project 'AI Chatbot' deployed successfully",
        type: "success",
        timestamp: new Date(Date.now() - 3600000).toISOString()
      },
      {
        id: 2,
        message: "GitHub repository created for 'Task Manager'",
        type: "info",
        timestamp: new Date(Date.now() - 7200000).toISOString()
      }
    ]);
  }
}

export default DataService;