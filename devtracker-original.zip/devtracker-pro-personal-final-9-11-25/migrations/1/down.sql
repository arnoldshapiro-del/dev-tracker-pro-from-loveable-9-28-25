
DROP TABLE sms_logs;
DROP TABLE appointments;
DROP TABLE patients;
