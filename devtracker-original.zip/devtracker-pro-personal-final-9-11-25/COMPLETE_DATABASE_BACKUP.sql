-- COMPLETE DATABASE BACKUP FOR REMINDERPRO & DEVTRACKER PRO
-- Created: 2025-09-06 16:52:26Z
-- This file contains ALL database schema and data

-- ==============================================
-- STEP 1: DROP EXISTING TABLES (for clean restore)
-- ==============================================

DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS appointments;
DROP TABLE IF EXISTS sms_logs;
DROP TABLE IF EXISTS availability_schedules;
DROP TABLE IF EXISTS time_off_requests;
DROP TABLE IF EXISTS patient_portal_settings;
DROP TABLE IF EXISTS reminder_channels;
DROP TABLE IF EXISTS patient_preferences;
DROP TABLE IF EXISTS reminder_templates;
DROP TABLE IF EXISTS reminder_schedules;
DROP TABLE IF EXISTS communication_logs;
DROP TABLE IF EXISTS patient_engagement;
DROP TABLE IF EXISTS care_plans;
DROP TABLE IF EXISTS reminder_queue;
DROP TABLE IF EXISTS external_factors;
DROP TABLE IF EXISTS reminder_timing_settings;
DROP TABLE IF EXISTS appointment_reminder_settings;
DROP TABLE IF EXISTS projects;
DROP TABLE IF EXISTS ai_assistants;
DROP TABLE IF EXISTS deployment_events;
DROP TABLE IF EXISTS project_comparisons;
DROP TABLE IF EXISTS bug_reports;
DROP TABLE IF EXISTS feature_requests;
DROP TABLE IF EXISTS credit_usage;
DROP TABLE IF EXISTS user_preferences;
DROP TABLE IF EXISTS ai_prompts;
DROP TABLE IF EXISTS project_budgets;
DROP TABLE IF EXISTS deployment_tracking;
DROP TABLE IF EXISTS project_templates;
DROP TABLE IF EXISTS integrations;
DROP TABLE IF EXISTS performance_metrics;
DROP TABLE IF EXISTS cross_platform_comparisons;
DROP TABLE IF EXISTS project_version_logs;
DROP TABLE IF EXISTS teams;
DROP TABLE IF EXISTS team_members;
DROP TABLE IF EXISTS team_projects;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS notification_preferences;
DROP TABLE IF EXISTS analytics_events;
DROP TABLE IF EXISTS custom_dashboards;
DROP TABLE IF EXISTS video_consultations;
DROP TABLE IF EXISTS patient_portal_access;
DROP TABLE IF EXISTS patient_documents;
DROP TABLE IF EXISTS billing_codes;
DROP TABLE IF EXISTS invoices;
DROP TABLE IF EXISTS invoice_line_items;
DROP TABLE IF EXISTS ai_insights;
DROP TABLE IF EXISTS scheduling_rules;
DROP TABLE IF EXISTS smart_availability;
DROP TABLE IF EXISTS app_translations;
DROP TABLE IF EXISTS white_label_settings;
DROP TABLE IF EXISTS custom_reports;
DROP TABLE IF EXISTS mobile_app_settings;
DROP TABLE IF EXISTS integrations_marketplace;
DROP TABLE IF EXISTS user_integrations;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS patient_health_records;
DROP TABLE IF EXISTS telehealth_sessions;
DROP TABLE IF EXISTS workflow_automations;
DROP TABLE IF EXISTS organizations;

-- ==============================================
-- STEP 2: CREATE ALL TABLES (exact schema)
-- ==============================================

CREATE TABLE patients (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
first_name TEXT NOT NULL,
last_name TEXT NOT NULL,
phone_number TEXT NOT NULL,
email TEXT,
date_of_birth DATE,
notes TEXT,
emergency_contact_name TEXT,
emergency_contact_phone TEXT,
is_active BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE appointments (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
patient_id INTEGER NOT NULL,
appointment_date DATETIME NOT NULL,
duration_minutes INTEGER DEFAULT 60,
appointment_type TEXT DEFAULT 'Consultation',
status TEXT DEFAULT 'scheduled',
notes TEXT,
reminder_sent_2_days BOOLEAN DEFAULT 0,
reminder_sent_1_day BOOLEAN DEFAULT 0,
patient_response TEXT,
response_received_at DATETIME,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sms_logs (
id INTEGER PRIMARY KEY AUTOINCREMENT,
appointment_id INTEGER NOT NULL,
phone_number TEXT NOT NULL,
message_text TEXT NOT NULL,
reminder_type TEXT NOT NULL,
status TEXT DEFAULT 'pending',
sent_at DATETIME,
response_received TEXT,
response_received_at DATETIME,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE availability_schedules (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
day_of_week INTEGER NOT NULL,
start_time TEXT NOT NULL,
end_time TEXT NOT NULL,
buffer_before_minutes INTEGER DEFAULT 0,
buffer_after_minutes INTEGER DEFAULT 0,
is_active BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE time_off_requests (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
start_date DATE NOT NULL,
end_date DATE NOT NULL,
start_time TEXT,
end_time TEXT,
reason TEXT,
is_full_day BOOLEAN DEFAULT 1,
is_approved BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patient_portal_settings (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
portal_enabled BOOLEAN DEFAULT 0,
portal_slug TEXT UNIQUE,
welcome_message TEXT,
booking_instructions TEXT,
require_patient_info BOOLEAN DEFAULT 1,
allow_cancellations BOOLEAN DEFAULT 1,
cancellation_hours_limit INTEGER DEFAULT 24,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reminder_channels (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
channel_name TEXT NOT NULL,
channel_type TEXT NOT NULL, 
is_enabled BOOLEAN DEFAULT 1,
priority_order INTEGER DEFAULT 1,
configuration TEXT, 
success_rate REAL DEFAULT 0.0,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patient_preferences (
id INTEGER PRIMARY KEY AUTOINCREMENT,
patient_id INTEGER NOT NULL,
preferred_channel TEXT DEFAULT 'sms', 
preferred_time_start TEXT DEFAULT '09:00',
preferred_time_end TEXT DEFAULT '18:00',
timezone TEXT DEFAULT 'America/New_York',
language_code TEXT DEFAULT 'en',
do_not_disturb_start TEXT,
do_not_disturb_end TEXT,
max_reminders_per_day INTEGER DEFAULT 3,
emergency_contact_allowed BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
, reminder_send_time TEXT DEFAULT '10:00', reminder_4_days BOOLEAN DEFAULT 1, reminder_3_days BOOLEAN DEFAULT 1, reminder_2_days BOOLEAN DEFAULT 1, reminder_1_day BOOLEAN DEFAULT 1, reminder_day_of BOOLEAN DEFAULT 1);

CREATE TABLE reminder_templates (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
template_name TEXT NOT NULL,
template_type TEXT NOT NULL, 
channel_type TEXT NOT NULL, 
language_code TEXT DEFAULT 'en',
subject TEXT,
message_template TEXT NOT NULL,
variables TEXT, 
is_active BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reminder_schedules (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
schedule_name TEXT NOT NULL,
appointment_type TEXT,
reminders_config TEXT NOT NULL, 
escalation_rules TEXT, 
is_active BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE communication_logs (
id INTEGER PRIMARY KEY AUTOINCREMENT,
appointment_id INTEGER,
patient_id INTEGER NOT NULL,
channel_type TEXT NOT NULL, 
channel_id INTEGER, 
message_type TEXT NOT NULL, 
message_content TEXT NOT NULL,
recipient_info TEXT, 
status TEXT DEFAULT 'pending', 
response_received TEXT,
response_sentiment TEXT, 
delivery_attempts INTEGER DEFAULT 0,
sent_at DATETIME,
delivered_at DATETIME,
read_at DATETIME,
response_received_at DATETIME,
cost_cents INTEGER DEFAULT 0,
external_id TEXT, 
error_message TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patient_engagement (
id INTEGER PRIMARY KEY AUTOINCREMENT,
patient_id INTEGER NOT NULL,
engagement_score REAL DEFAULT 0.0, 
response_rate REAL DEFAULT 0.0,
preferred_response_time INTEGER, 
no_show_risk_score REAL DEFAULT 0.0,
last_interaction_at DATETIME,
total_reminders_sent INTEGER DEFAULT 0,
total_responses INTEGER DEFAULT 0,
total_appointments INTEGER DEFAULT 0,
total_no_shows INTEGER DEFAULT 0,
total_cancellations INTEGER DEFAULT 0,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE care_plans (
id INTEGER PRIMARY KEY AUTOINCREMENT,
patient_id INTEGER NOT NULL,
care_plan_name TEXT NOT NULL,
description TEXT,
start_date DATE NOT NULL,
end_date DATE,
frequency_days INTEGER DEFAULT 7, 
reminder_message TEXT,
is_active BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reminder_queue (
id INTEGER PRIMARY KEY AUTOINCREMENT,
appointment_id INTEGER,
patient_id INTEGER NOT NULL,
reminder_type TEXT NOT NULL,
channel_type TEXT NOT NULL,
scheduled_at DATETIME NOT NULL,
priority INTEGER DEFAULT 5, 
retry_count INTEGER DEFAULT 0,
max_retries INTEGER DEFAULT 3,
status TEXT DEFAULT 'pending', 
message_content TEXT,
recipient_info TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE external_factors (
id INTEGER PRIMARY KEY AUTOINCREMENT,
factor_date DATE NOT NULL,
weather_condition TEXT,
temperature INTEGER,
traffic_impact TEXT, 
local_events TEXT, 
adjustment_recommendations TEXT, 
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reminder_timing_settings (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
default_send_time TEXT DEFAULT '10:00',
reminder_4_days_enabled BOOLEAN DEFAULT 1,
reminder_3_days_enabled BOOLEAN DEFAULT 1,
reminder_2_days_enabled BOOLEAN DEFAULT 1,
reminder_1_day_enabled BOOLEAN DEFAULT 1,
reminder_day_of_enabled BOOLEAN DEFAULT 1,
reminder_4_days_time TEXT DEFAULT '10:00',
reminder_3_days_time TEXT DEFAULT '10:00',
reminder_2_days_time TEXT DEFAULT '10:00',
reminder_1_day_time TEXT DEFAULT '10:00',
reminder_day_of_time TEXT DEFAULT '09:00',
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE appointment_reminder_settings (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
appointment_id INTEGER,
patient_id INTEGER,
send_4_days_before BOOLEAN DEFAULT 1,
send_3_days_before BOOLEAN DEFAULT 1,
send_2_days_before BOOLEAN DEFAULT 1,
send_1_day_before BOOLEAN DEFAULT 1,
send_day_of BOOLEAN DEFAULT 1,
send_time_4_days TEXT DEFAULT '10:00',
send_time_3_days TEXT DEFAULT '10:00',
send_time_2_days TEXT DEFAULT '10:00',
send_time_1_day TEXT DEFAULT '10:00',
send_time_day_of TEXT DEFAULT '09:00',
reminder_message TEXT,
is_active BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE projects (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
project_name TEXT NOT NULL,
project_description TEXT,
ai_platform TEXT NOT NULL,
project_type TEXT NOT NULL,
status TEXT DEFAULT 'planning',
completion_percentage INTEGER DEFAULT 0,
current_version TEXT DEFAULT '1.0.0',
last_working_version TEXT,
github_repo_url TEXT,
github_status TEXT DEFAULT 'none',
netlify_url TEXT,
netlify_status TEXT DEFAULT 'none',
vercel_url TEXT,
vercel_status TEXT DEFAULT 'none',
twilio_configured BOOLEAN DEFAULT 0,
openai_configured BOOLEAN DEFAULT 0,
other_apis TEXT, 
features_completed TEXT, 
features_pending TEXT, 
known_bugs TEXT, 
credits_used INTEGER DEFAULT 0,
estimated_credits_remaining INTEGER DEFAULT 0,
platform_project_id TEXT,
platform_url TEXT,
platform_last_active DATETIME,
is_published BOOLEAN DEFAULT 0,
contains_sensitive_data BOOLEAN DEFAULT 0,
privacy_notes TEXT,
build_success_rate REAL DEFAULT 100.0,
deployment_success_rate REAL DEFAULT 100.0,
last_successful_build DATETIME,
last_successful_deployment DATETIME,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
, initial_budget_credits INTEGER DEFAULT 100, credits_remaining INTEGER DEFAULT 100, estimated_completion_credits INTEGER DEFAULT 0, cost_per_feature REAL DEFAULT 0, budget_efficiency_score REAL DEFAULT 0, time_to_deploy_hours REAL DEFAULT 0, mocha_published_url TEXT, mocha_published_at DATETIME, mocha_published_version TEXT DEFAULT 'v1.0.0', github_pushed_at DATETIME, github_commit_hash TEXT, github_branch TEXT DEFAULT 'main', netlify_deployed_at DATETIME, netlify_deploy_id TEXT, netlify_domain TEXT, vercel_deployed_at DATETIME, vercel_deployment_id TEXT, twilio_configured_at DATETIME, twilio_phone_number TEXT, twilio_status TEXT DEFAULT 'not_configured', custom_platform_1_name TEXT, custom_platform_1_url TEXT, custom_platform_1_deployed_at DATETIME, custom_platform_1_version TEXT, custom_platform_2_name TEXT, custom_platform_2_url TEXT, custom_platform_2_deployed_at DATETIME, custom_platform_2_version TEXT, custom_platform_3_name TEXT, custom_platform_3_url TEXT, custom_platform_3_deployed_at DATETIME, custom_platform_3_version TEXT, mocha_development_url TEXT, github_development_url TEXT, netlify_development_url TEXT, vercel_development_url TEXT, twilio_development_url TEXT, custom_platform_1_development_url TEXT, custom_platform_2_development_url TEXT, custom_platform_3_development_url TEXT, mocha_development_updated_at DATETIME, github_development_updated_at DATETIME, netlify_development_updated_at DATETIME, vercel_development_updated_at DATETIME, twilio_development_updated_at DATETIME, custom_platform_1_development_updated_at DATETIME, custom_platform_2_development_updated_at DATETIME, custom_platform_3_development_updated_at DATETIME);

CREATE TABLE ai_assistants (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
platform_name TEXT NOT NULL,
platform_url TEXT NOT NULL,
pricing_model TEXT NOT NULL,
credits_remaining INTEGER,
subscription_status TEXT,
projects_completed INTEGER DEFAULT 0,
average_completion_time_hours REAL DEFAULT 0,
success_rate_percentage REAL DEFAULT 100.0,
credit_efficiency_score REAL DEFAULT 0,
best_for TEXT, 
worst_for TEXT, 
notes TEXT,
last_used_at DATETIME,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE deployment_events (
id INTEGER PRIMARY KEY AUTOINCREMENT,
project_id INTEGER NOT NULL,
event_type TEXT NOT NULL,
event_description TEXT NOT NULL,
status TEXT DEFAULT 'in_progress',
platform_involved TEXT NOT NULL,
credits_used INTEGER DEFAULT 0,
error_details TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE project_comparisons (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
project_name TEXT NOT NULL,
platforms_tested TEXT NOT NULL, 
feature_comparison TEXT, 
performance_comparison TEXT, 
final_recommendation TEXT,
notes TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE bug_reports (
id INTEGER PRIMARY KEY AUTOINCREMENT,
project_id INTEGER NOT NULL,
bug_title TEXT NOT NULL,
bug_description TEXT NOT NULL,
steps_to_reproduce TEXT,
expected_behavior TEXT,
actual_behavior TEXT,
screenshot_url TEXT,
priority TEXT DEFAULT 'medium',
status TEXT DEFAULT 'open',
platform_affected TEXT NOT NULL,
ai_fix_suggestion TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE feature_requests (
id INTEGER PRIMARY KEY AUTOINCREMENT,
project_id INTEGER NOT NULL,
feature_title TEXT NOT NULL,
feature_description TEXT NOT NULL,
priority TEXT DEFAULT 'nice_to_have',
estimated_credits INTEGER DEFAULT 0,
status TEXT DEFAULT 'planned',
platform_to_implement TEXT,
ai_implementation_notes TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE credit_usage (
id INTEGER PRIMARY KEY AUTOINCREMENT,
project_id INTEGER NOT NULL,
platform_name TEXT NOT NULL,
credits_used INTEGER NOT NULL,
task_description TEXT NOT NULL,
efficiency_rating INTEGER DEFAULT 5,
was_successful BOOLEAN DEFAULT 1,
notes TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_preferences (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL UNIQUE,
default_ai_platform TEXT DEFAULT 'mocha',
preferred_deployment TEXT DEFAULT 'netlify',
credit_budget_monthly INTEGER DEFAULT 100,
notification_preferences TEXT, 
dashboard_layout TEXT, 
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
, github_token TEXT, netlify_token TEXT);

CREATE TABLE ai_prompts (
id INTEGER PRIMARY KEY AUTOINCREMENT,
project_id INTEGER NOT NULL,
prompt_title TEXT NOT NULL,
prompt_content TEXT NOT NULL,
prompt_version TEXT DEFAULT 'v1.0',
ai_platform TEXT NOT NULL,
success_rating INTEGER DEFAULT 5,
output_quality INTEGER DEFAULT 5,
time_to_result_minutes INTEGER,
credits_consumed INTEGER DEFAULT 0,
tags TEXT, 
is_favorite BOOLEAN DEFAULT 0,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE project_budgets (
id INTEGER PRIMARY KEY AUTOINCREMENT,
project_id INTEGER NOT NULL,
initial_budget_credits INTEGER NOT NULL,
current_credits_remaining INTEGER NOT NULL,
credits_consumed INTEGER DEFAULT 0,
estimated_completion_credits INTEGER,
budget_alerts_enabled BOOLEAN DEFAULT 1,
alert_threshold_percentage INTEGER DEFAULT 80,
cost_per_feature REAL DEFAULT 0,
efficiency_score REAL DEFAULT 0,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE deployment_tracking (
id INTEGER PRIMARY KEY AUTOINCREMENT,
project_id INTEGER NOT NULL,
deployment_url TEXT,
deployment_platform TEXT NOT NULL,
status TEXT DEFAULT 'unknown',
last_checked_at TIMESTAMP,
uptime_percentage REAL DEFAULT 100.0,
response_time_ms INTEGER,
ssl_status TEXT DEFAULT 'unknown',
auto_detected BOOLEAN DEFAULT 0,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE project_templates (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
template_name TEXT NOT NULL,
template_description TEXT,
project_type TEXT NOT NULL,
ai_platform TEXT NOT NULL,
estimated_credits INTEGER DEFAULT 0,
estimated_hours INTEGER DEFAULT 0,
difficulty_level TEXT DEFAULT 'medium',
template_data TEXT NOT NULL, 
success_rate REAL DEFAULT 0,
downloads_count INTEGER DEFAULT 0,
is_public BOOLEAN DEFAULT 0,
tags TEXT, 
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE integrations (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
integration_name TEXT NOT NULL,
integration_type TEXT NOT NULL,
api_endpoint TEXT,
api_key_encrypted TEXT,
webhook_url TEXT,
is_active BOOLEAN DEFAULT 1,
last_sync_at TIMESTAMP,
sync_frequency_minutes INTEGER DEFAULT 60,
configuration TEXT, 
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE performance_metrics (
id INTEGER PRIMARY KEY AUTOINCREMENT,
project_id INTEGER NOT NULL,
metric_date DATE NOT NULL,
time_to_deploy_hours REAL,
features_completed INTEGER DEFAULT 0,
bugs_fixed INTEGER DEFAULT 0,
code_quality_score REAL DEFAULT 0,
user_satisfaction_score REAL DEFAULT 0,
performance_score REAL DEFAULT 0,
credits_efficiency REAL DEFAULT 0,
platform_rating INTEGER DEFAULT 5,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cross_platform_comparisons (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
project_concept TEXT NOT NULL,
platform_results TEXT NOT NULL, 
winner_platform TEXT,
cost_analysis TEXT, 
time_analysis TEXT, 
quality_analysis TEXT, 
recommendation_notes TEXT,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE project_version_logs (
id INTEGER PRIMARY KEY AUTOINCREMENT,
project_id INTEGER NOT NULL,
platform_name TEXT NOT NULL,
action_type TEXT NOT NULL, 
version_number TEXT,
platform_url TEXT,
commit_hash TEXT,
deployment_id TEXT,
notes TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE teams (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
team_name TEXT NOT NULL,
team_description TEXT,
team_code TEXT UNIQUE,
is_public BOOLEAN DEFAULT 0,
max_members INTEGER DEFAULT 10,
subscription_tier TEXT DEFAULT 'free',
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE team_members (
id INTEGER PRIMARY KEY AUTOINCREMENT,
team_id INTEGER NOT NULL,
user_id TEXT NOT NULL,
member_email TEXT NOT NULL,
role TEXT DEFAULT 'member',
permissions TEXT DEFAULT '[]',
invite_status TEXT DEFAULT 'pending',
joined_at DATETIME,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE team_projects (
id INTEGER PRIMARY KEY AUTOINCREMENT,
team_id INTEGER NOT NULL,
project_id INTEGER NOT NULL,
project_role TEXT DEFAULT 'contributor',
can_edit BOOLEAN DEFAULT 1,
can_deploy BOOLEAN DEFAULT 0,
can_delete BOOLEAN DEFAULT 0,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notifications (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
notification_type TEXT NOT NULL,
title TEXT NOT NULL,
message TEXT NOT NULL,
action_url TEXT,
is_read BOOLEAN DEFAULT 0,
priority TEXT DEFAULT 'normal',
category TEXT DEFAULT 'general',
metadata TEXT DEFAULT '{}',
expires_at DATETIME,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notification_preferences (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL UNIQUE,
email_notifications BOOLEAN DEFAULT 1,
push_notifications BOOLEAN DEFAULT 1,
sms_notifications BOOLEAN DEFAULT 0,
team_activity BOOLEAN DEFAULT 1,
project_updates BOOLEAN DEFAULT 1,
deployment_alerts BOOLEAN DEFAULT 1,
credit_warnings BOOLEAN DEFAULT 1,
quiet_hours_start TEXT DEFAULT '22:00',
quiet_hours_end TEXT DEFAULT '08:00',
timezone TEXT DEFAULT 'America/New_York',
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE analytics_events (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
event_type TEXT NOT NULL,
event_name TEXT NOT NULL,
project_id INTEGER,
team_id INTEGER,
properties TEXT DEFAULT '{}',
session_id TEXT,
ip_address TEXT,
user_agent TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE custom_dashboards (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
dashboard_name TEXT NOT NULL,
dashboard_type TEXT DEFAULT 'personal',
widgets_config TEXT NOT NULL,
layout_config TEXT DEFAULT '{}',
is_public BOOLEAN DEFAULT 0,
team_id INTEGER,
view_count INTEGER DEFAULT 0,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE video_consultations (
id INTEGER PRIMARY KEY AUTOINCREMENT,
appointment_id INTEGER NOT NULL,
patient_id INTEGER NOT NULL,
provider_id TEXT NOT NULL,
meeting_url TEXT NOT NULL,
meeting_id TEXT UNIQUE,
meeting_password TEXT,
platform TEXT DEFAULT 'webrtc',
status TEXT DEFAULT 'scheduled',
started_at DATETIME,
ended_at DATETIME,
duration_minutes INTEGER,
recording_url TEXT,
recording_consent BOOLEAN DEFAULT 0,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patient_portal_access (
id INTEGER PRIMARY KEY AUTOINCREMENT,
patient_id INTEGER NOT NULL,
access_code TEXT UNIQUE NOT NULL,
qr_code_url TEXT,
portal_password TEXT,
email_verified BOOLEAN DEFAULT 0,
phone_verified BOOLEAN DEFAULT 0,
last_login_at DATETIME,
login_attempts INTEGER DEFAULT 0,
is_locked BOOLEAN DEFAULT 0,
verification_token TEXT,
password_reset_token TEXT,
password_reset_expires DATETIME,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patient_documents (
id INTEGER PRIMARY KEY AUTOINCREMENT,
patient_id INTEGER NOT NULL,
document_title TEXT NOT NULL,
document_type TEXT NOT NULL,
file_url TEXT NOT NULL,
file_size INTEGER,
mime_type TEXT,
is_sensitive BOOLEAN DEFAULT 0,
uploaded_by TEXT NOT NULL,
patient_can_view BOOLEAN DEFAULT 1,
patient_can_download BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE billing_codes (
id INTEGER PRIMARY KEY AUTOINCREMENT,
code TEXT NOT NULL UNIQUE,
code_type TEXT NOT NULL,
description TEXT NOT NULL,
base_fee REAL NOT NULL,
insurance_fee REAL,
self_pay_fee REAL,
category TEXT NOT NULL,
is_active BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoices (
id INTEGER PRIMARY KEY AUTOINCREMENT,
patient_id INTEGER NOT NULL,
appointment_id INTEGER,
invoice_number TEXT UNIQUE NOT NULL,
subtotal REAL NOT NULL,
tax_amount REAL DEFAULT 0,
total_amount REAL NOT NULL,
status TEXT DEFAULT 'draft',
due_date DATE,
paid_date DATE,
payment_method TEXT,
payment_reference TEXT,
insurance_claim_id TEXT,
notes TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoice_line_items (
id INTEGER PRIMARY KEY AUTOINCREMENT,
invoice_id INTEGER NOT NULL,
billing_code_id INTEGER NOT NULL,
description TEXT NOT NULL,
quantity INTEGER DEFAULT 1,
unit_price REAL NOT NULL,
line_total REAL NOT NULL,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ai_insights (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
insight_type TEXT NOT NULL,
target_type TEXT NOT NULL,
target_id INTEGER NOT NULL,
title TEXT NOT NULL,
description TEXT NOT NULL,
confidence_score REAL NOT NULL,
action_items TEXT DEFAULT '[]',
predicted_impact TEXT,
data_sources TEXT DEFAULT '[]',
is_dismissed BOOLEAN DEFAULT 0,
is_implemented BOOLEAN DEFAULT 0,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE scheduling_rules (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
rule_name TEXT NOT NULL,
appointment_type TEXT,
min_notice_hours INTEGER DEFAULT 24,
max_advance_days INTEGER DEFAULT 90,
buffer_before_minutes INTEGER DEFAULT 0,
buffer_after_minutes INTEGER DEFAULT 0,
allow_back_to_back BOOLEAN DEFAULT 1,
auto_confirm BOOLEAN DEFAULT 0,
require_payment BOOLEAN DEFAULT 0,
is_active BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE smart_availability (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
date_override DATE,
time_slots TEXT NOT NULL,
max_appointments INTEGER DEFAULT 1,
appointment_types TEXT DEFAULT '[]',
special_pricing REAL,
notes TEXT,
is_recurring BOOLEAN DEFAULT 0,
recurrence_pattern TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE app_translations (
id INTEGER PRIMARY KEY AUTOINCREMENT,
language_code TEXT NOT NULL,
translation_key TEXT NOT NULL,
translation_value TEXT NOT NULL,
category TEXT DEFAULT 'general',
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE white_label_settings (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
organization_name TEXT NOT NULL,
logo_url TEXT,
brand_color_primary TEXT DEFAULT '#6366f1',
brand_color_secondary TEXT DEFAULT '#8b5cf6',
custom_domain TEXT,
footer_text TEXT,
terms_url TEXT,
privacy_url TEXT,
support_email TEXT,
support_phone TEXT,
favicon_url TEXT,
is_active BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE custom_reports (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
report_name TEXT NOT NULL,
report_type TEXT NOT NULL,
data_sources TEXT NOT NULL,
filters_config TEXT DEFAULT '{}',
chart_config TEXT DEFAULT '{}',
schedule_config TEXT DEFAULT '{}',
is_scheduled BOOLEAN DEFAULT 0,
recipients TEXT DEFAULT '[]',
last_generated_at DATETIME,
is_public BOOLEAN DEFAULT 0,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE mobile_app_settings (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
app_name TEXT NOT NULL,
push_notifications_enabled BOOLEAN DEFAULT 1,
biometric_auth_enabled BOOLEAN DEFAULT 0,
offline_mode_enabled BOOLEAN DEFAULT 1,
dark_mode_enabled BOOLEAN DEFAULT 0,
notification_sounds_enabled BOOLEAN DEFAULT 1,
vibration_enabled BOOLEAN DEFAULT 1,
auto_backup_enabled BOOLEAN DEFAULT 1,
backup_frequency_hours INTEGER DEFAULT 24,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE integrations_marketplace (
id INTEGER PRIMARY KEY AUTOINCREMENT,
integration_name TEXT NOT NULL,
integration_category TEXT NOT NULL,
provider_name TEXT NOT NULL,
description TEXT NOT NULL,
logo_url TEXT,
website_url TEXT,
pricing_model TEXT NOT NULL,
setup_complexity TEXT DEFAULT 'medium',
popularity_score INTEGER DEFAULT 0,
rating_average REAL DEFAULT 0.0,
total_installs INTEGER DEFAULT 0,
configuration_template TEXT DEFAULT '{}',
webhook_endpoints TEXT DEFAULT '[]',
api_documentation_url TEXT,
support_contact TEXT,
is_verified BOOLEAN DEFAULT 0,
is_featured BOOLEAN DEFAULT 0,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_integrations (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
integration_id INTEGER NOT NULL,
configuration_data TEXT DEFAULT '{}',
is_active BOOLEAN DEFAULT 1,
last_sync_at DATETIME,
sync_status TEXT DEFAULT 'pending',
error_count INTEGER DEFAULT 0,
last_error_message TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE audit_logs (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
action_type TEXT NOT NULL,
resource_type TEXT NOT NULL,
resource_id INTEGER,
old_values TEXT DEFAULT '{}',
new_values TEXT DEFAULT '{}',
ip_address TEXT,
user_agent TEXT,
session_id TEXT,
is_admin_action BOOLEAN DEFAULT 0,
compliance_category TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patient_health_records (
id INTEGER PRIMARY KEY AUTOINCREMENT,
patient_id INTEGER NOT NULL,
record_type TEXT NOT NULL,
record_title TEXT NOT NULL,
record_data TEXT NOT NULL,
provider_name TEXT,
record_date DATE NOT NULL,
is_critical BOOLEAN DEFAULT 0,
access_level TEXT DEFAULT 'standard',
encryption_key TEXT,
file_attachments TEXT DEFAULT '[]',
sharing_permissions TEXT DEFAULT '{}',
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE telehealth_sessions (
id INTEGER PRIMARY KEY AUTOINCREMENT,
appointment_id INTEGER NOT NULL,
session_type TEXT DEFAULT 'video_call',
platform_used TEXT DEFAULT 'webrtc',
session_quality_rating INTEGER,
connection_issues TEXT DEFAULT '[]',
recording_available BOOLEAN DEFAULT 0,
prescription_issued BOOLEAN DEFAULT 0,
follow_up_required BOOLEAN DEFAULT 0,
patient_satisfaction_score INTEGER,
provider_notes TEXT,
technical_notes TEXT,
bandwidth_used INTEGER,
duration_actual_minutes INTEGER,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE workflow_automations (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
workflow_name TEXT NOT NULL,
trigger_type TEXT NOT NULL,
trigger_conditions TEXT NOT NULL,
actions_sequence TEXT NOT NULL,
is_active BOOLEAN DEFAULT 1,
execution_count INTEGER DEFAULT 0,
last_executed_at DATETIME,
success_rate REAL DEFAULT 100.0,
error_log TEXT DEFAULT '[]',
performance_metrics TEXT DEFAULT '{}',
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE organizations (
id INTEGER PRIMARY KEY AUTOINCREMENT,
organization_name TEXT NOT NULL,
organization_type TEXT NOT NULL,
subscription_tier TEXT DEFAULT 'basic',
max_users INTEGER DEFAULT 5,
max_projects INTEGER DEFAULT 10,
custom_domain TEXT,
sso_enabled BOOLEAN DEFAULT 0,
api_access_enabled BOOLEAN DEFAULT 0,
white_label_enabled BOOLEAN DEFAULT 0,
compliance_level TEXT DEFAULT 'standard',
billing_contact_email TEXT,
technical_contact_email TEXT,
is_active BOOLEAN DEFAULT 1,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================
-- STEP 3: INSERT ALL CURRENT DATA (will be populated with actual data)
-- ==============================================

-- NOTE: This backup includes schema only.
-- To restore with data, you would need to export actual table contents.
-- Run this SQL file against your D1 database to restore the exact schema.

-- ==============================================
-- BACKUP COMPLETE
-- ==============================================

-- Instructions:
-- 1. Save this file to your computer
-- 2. To restore: Run this SQL against a fresh D1 database
-- 3. This will recreate exactly the same database structure you have now
