export default function TemplateMarketplace() {
  return (
    <div className="text-center py-8">
      <h3 className="text-lg font-medium text-gray-900 mb-2">Template Marketplace</h3>
      <p className="text-gray-500">Project templates and starter kits coming soon...</p>
    </div>
  );
}