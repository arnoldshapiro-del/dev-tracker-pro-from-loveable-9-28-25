// Dark mode utility classes to match the reference image exactly
export const darkModeClasses = {
  // Main background - very dark black like in the image
  mainBg: 'bg-gray-50 dark:bg-[#0f0f0f]',
  
  // Sidebar background - dark gray like in the image
  sidebarBg: 'bg-white dark:bg-[#1a1a1a]',
  
  // Card backgrounds - dark like in the image, not white
  cardBg: 'bg-white dark:bg-[#2a2a2a]',
  
  // Modal backgrounds
  modalBg: 'bg-white dark:bg-[#2a2a2a]',
  
  // Input backgrounds
  inputBg: 'bg-white dark:bg-[#2a2a2a]',
  
  // Border colors
  border: 'border-gray-200 dark:border-gray-700',
  
  // Text colors
  textPrimary: 'text-gray-900 dark:text-gray-100',
  textSecondary: 'text-gray-600 dark:text-gray-300',
  textMuted: 'text-gray-500 dark:text-gray-400',
  
  // Button backgrounds
  buttonSecondary: 'bg-white dark:bg-[#2a2a2a] border-gray-300 dark:border-gray-600',
  
  // Table backgrounds
  tableBg: 'bg-white dark:bg-[#2a2a2a]',
  tableRowBg: 'bg-white dark:bg-[#2a2a2a]',
  
  // Hover states
  hoverBg: 'hover:bg-gray-50 dark:hover:bg-[#3a3a3a]',
};

export const getDarkModeStyle = (element: keyof typeof darkModeClasses) => {
  return darkModeClasses[element];
};
