# Requested UI Theme Change — SPEC (Match "Left Screenshot" Look)

**Goal:** Replace the current solid/gradient project cards with *white cards* and *subtle accent chips/bars*, matching the attached screenshot ("left screenshot" look).

## Must-Haves
1. Cards use white surfaces with a 1px #E5E7EB border, 14px radius, no gradient or solid color fills.
2. Accent color should appear only in:
   - Small tinted chips (12% tint on white, bold label text in the same hue).
   - Thin progress/budget bars (8px height) with rounded ends.
   - Primary CTA ("Complete Editor" bar/button) in primary accent (teal/green).
3. Typography: Inter (or system-ui fallback), #111827 text, #6B7280 for muted text.
4. Spacing: 18px padding inside cards; 8px gap between chips; 16px vertical spacing between stacked cards.
5. Keep current layout and data; this is strictly a **theme**/CSS change.

## Color Tokens (from screenshot)
- Primary/teal: #E8A890
- Purple: #F0D0A0
- Orange: #A0D8C8
- Blue: #B098F0
- Green: #10A37D
- Red: #8B5CF6
- Neutrals: bg #FAFAFA · surface #FFFFFF · border #E5E7EB · text #111827 · muted #6B7280

See `lovable-theme.css` for CSS variables and `tailwind.config.js` snippet for teams using Tailwind.