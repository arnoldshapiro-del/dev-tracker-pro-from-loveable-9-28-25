# DevTracker Pro

## Overview
DevTracker Pro is a comprehensive AI development project management system that was separated from a dual-mode application. It provides advanced project tracking, budget management, deployment automation, and team collaboration features specifically designed for AI-powered development workflows. The application helps developers manage their AI development projects, track credit usage across multiple platforms, and automate deployment processes to GitHub and Netlify.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 19.0.0 with TypeScript 5.8.3
- **Routing**: React Router 7.5.3 for client-side navigation
- **Styling**: Tailwind CSS 3.4.17 with custom dark mode support
- **Icons**: Lucide React 0.510.0 for consistent iconography
- **Charts**: Recharts 3.1.0 for data visualization
- **Drag & Drop**: @dnd-kit/core 6.3.1 for sortable interfaces
- **Build Tool**: Vite 7.1.3 for fast development and building

### Backend Architecture
- **Framework**: Hono 4.7.7 (lightweight web framework)
- **Runtime**: Cloudflare Workers for serverless execution
- **Database**: Cloudflare D1 (SQLite-based) for data persistence
- **Authentication**: Custom shim replacing @getmocha/users-service for personal use
- **Validation**: Zod 3.24.3 for type-safe data validation

### Key Architectural Decisions
1. **Single Page Application**: Implements client-side routing with React Router for smooth navigation
2. **Component-Based Architecture**: Modular components in `/components/` for reusability
3. **TypeScript Integration**: Strong typing throughout the application for better developer experience
4. **Responsive Design**: Mobile-first approach with Tailwind CSS utilities
5. **Dark Mode Support**: CSS variables and class-based dark mode implementation
6. **State Management**: React hooks and local state management (no external state library)

### Core Features
1. **Project Management**: Complete CRUD operations for AI development projects
2. **Credit Tracking**: Smart credits system for monitoring AI platform usage
3. **Deployment Automation**: Integration with GitHub and Netlify APIs
4. **Team Collaboration**: Multi-user project sharing and permissions
5. **Analytics Dashboard**: Visual reporting with charts and metrics
6. **AI Platform Comparison**: Side-by-side comparison of different AI development platforms

## External Dependencies

### Third-Party Services
- **GitHub API**: For repository creation and file management during automated deployment
- **Netlify API**: For automated site deployment and configuration
- **Cloudflare D1**: Database service for data persistence
- **Cloudflare Workers**: Serverless runtime environment

### Development Dependencies
- **ESLint**: Code linting with TypeScript support
- **PostCSS & Autoprefixer**: CSS processing and vendor prefixing
- **Wrangler**: Cloudflare Workers deployment tool

### API Integrations
- **GitHub Personal Access Token**: Required for repository operations
- **Netlify Personal Access Token**: Required for site deployment
- **Mocha Users Service**: Authentication service (shimmed for personal use)

### Environment Variables
The application expects the following environment variables:
- `GITHUB_PERSONAL_ACCESS_TOKEN`: For GitHub API access
- `NETLIFY_PERSONAL_ACCESS_TOKEN`: For Netlify API access
- `MOCHA_USERS_SERVICE_API_URL`: Authentication service URL
- `MOCHA_USERS_SERVICE_API_KEY`: Authentication service key

### Database Schema
Uses Cloudflare D1 with tables for:
- Projects and their metadata
- Credit tracking sessions
- Team collaboration data
- Deployment history and logs
- AI assistant comparisons and benchmarks