import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  X, 
  Calendar, 
  Tag, 
  Hash,
  BarChart3,
  CheckCircle,
  Brain,
  Star,
  DollarSign
} from 'lucide-react';

interface SearchFilter {
  id: string;
  label: string;
  type: 'text' | 'select' | 'date' | 'number' | 'boolean';
  options?: Array<{ value: string; label: string }>;
  placeholder?: string;
  icon?: React.ComponentType<any>;
}

interface AdvancedSearchProps {
  data: any[];
  onFilter: (filteredData: any[]) => void;
  searchFields: string[];
  filters: SearchFilter[];
  placeholder?: string;
  className?: string;
}

export default function AdvancedSearch({ 
  data, 
  onFilter, 
  searchFields, 
  filters, 
  placeholder = "Search across all data...",
  className = ""
}: AdvancedSearchProps) {
  const [query, setQuery] = useState('');
  const [activeFilters, setActiveFilters] = useState<Record<string, any>>({});
  const [showFilters, setShowFilters] = useState(false);
  const [savedSearches, setSavedSearches] = useState<Array<{ name: string; query: string; filters: Record<string, any> }>>([]);

  // Load saved searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('advanced-searches');
    if (saved) {
      setSavedSearches(JSON.parse(saved));
    }
  }, []);

  // Advanced search with multiple criteria
  const filteredData = useMemo(() => {
    let result = [...data];

    // Text search across specified fields
    if (query.trim()) {
      const searchTerms = query.toLowerCase().split(' ').filter(term => term.length > 0);
      
      result = result.filter(item => {
        return searchTerms.every(term => {
          return searchFields.some(field => {
            const value = getNestedValue(item, field);
            return value && value.toString().toLowerCase().includes(term);
          });
        });
      });
    }

    // Apply active filters
    Object.entries(activeFilters).forEach(([filterId, filterValue]) => {
      if (filterValue === undefined || filterValue === '' || filterValue === null) return;

      const filter = filters.find(f => f.id === filterId);
      if (!filter) return;

      result = result.filter(item => {
        const itemValue = getNestedValue(item, filterId);
        
        switch (filter.type) {
          case 'text':
            return itemValue && itemValue.toString().toLowerCase().includes(filterValue.toLowerCase());
          case 'select':
            return itemValue === filterValue;
          case 'boolean':
            return Boolean(itemValue) === Boolean(filterValue);
          case 'number':
            return Number(itemValue) >= Number(filterValue);
          case 'date':
            const itemDate = new Date(itemValue);
            const filterDate = new Date(filterValue);
            return itemDate >= filterDate;
          default:
            return true;
        }
      });
    });

    return result;
  }, [data, query, activeFilters, searchFields, filters]);

  // Update parent component when filtered data changes
  useEffect(() => {
    onFilter(filteredData);
  }, [filteredData, onFilter]);

  // Helper function to get nested object values
  const getNestedValue = (obj: any, path: string) => {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  };

  // Save current search
  const saveCurrentSearch = () => {
    const name = prompt('Enter a name for this search:');
    if (!name) return;

    const newSearch = {
      name,
      query,
      filters: activeFilters
    };

    const updated = [...savedSearches, newSearch];
    setSavedSearches(updated);
    localStorage.setItem('advanced-searches', JSON.stringify(updated));
  };

  // Load saved search
  const loadSavedSearch = (search: typeof savedSearches[0]) => {
    setQuery(search.query);
    setActiveFilters(search.filters);
    setShowFilters(Object.keys(search.filters).length > 0);
  };

  // Clear all filters
  const clearAll = () => {
    setQuery('');
    setActiveFilters({});
    setShowFilters(false);
  };

  // Update filter value
  const updateFilter = (filterId: string, value: any) => {
    setActiveFilters(prev => ({
      ...prev,
      [filterId]: value
    }));
  };

  // Remove specific filter
  const removeFilter = (filterId: string) => {
    setActiveFilters(prev => {
      const updated = { ...prev };
      delete updated[filterId];
      return updated;
    });
  };

  const activeFilterCount = Object.keys(activeFilters).filter(key => 
    activeFilters[key] !== undefined && activeFilters[key] !== '' && activeFilters[key] !== null
  ).length;

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Main Search Bar */}
      <div className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={placeholder}
            className="w-full pl-10 pr-20 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
          />
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center space-x-2">
            {query && (
              <button
                onClick={() => setQuery('')}
                className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`p-2 rounded-lg transition-colors ${
                showFilters || activeFilterCount > 0
                  ? 'bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-300'
                  : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-300'
              }`}
            >
              <Filter className="w-4 h-4" />
              {activeFilterCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-purple-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {activeFilterCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Search Results Count */}
        <div className="flex items-center justify-between mt-2">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            {filteredData.length} {filteredData.length === 1 ? 'result' : 'results'} found
            {query && ` for "${query}"`}
          </div>
          <div className="flex items-center space-x-2">
            {(query || activeFilterCount > 0) && (
              <button
                onClick={clearAll}
                className="text-sm text-purple-600 hover:text-purple-700 dark:text-purple-400"
              >
                Clear all
              </button>
            )}
            {(query || activeFilterCount > 0) && (
              <button
                onClick={saveCurrentSearch}
                className="text-sm bg-purple-100 text-purple-700 px-2 py-1 rounded hover:bg-purple-200 dark:bg-purple-900 dark:text-purple-300"
              >
                Save search
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Advanced Filters Panel */}
      {showFilters && (
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center">
              <Filter className="w-5 h-5 mr-2" />
              Advanced Filters
            </h3>
            <button
              onClick={() => setShowFilters(false)}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Filter Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filters.map((filter) => {
              const Icon = filter.icon || Hash;
              return (
                <div key={filter.id} className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                    <Icon className="w-4 h-4 mr-2" />
                    {filter.label}
                  </label>
                  
                  {filter.type === 'text' && (
                    <input
                      type="text"
                      value={activeFilters[filter.id] || ''}
                      onChange={(e) => updateFilter(filter.id, e.target.value)}
                      placeholder={filter.placeholder}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    />
                  )}

                  {filter.type === 'select' && (
                    <select
                      value={activeFilters[filter.id] || ''}
                      onChange={(e) => updateFilter(filter.id, e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                    >
                      <option value="">All {filter.label}</option>
                      {filter.options?.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  )}

                  {filter.type === 'date' && (
                    <input
                      type="date"
                      value={activeFilters[filter.id] || ''}
                      onChange={(e) => updateFilter(filter.id, e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                    />
                  )}

                  {filter.type === 'number' && (
                    <input
                      type="number"
                      value={activeFilters[filter.id] || ''}
                      onChange={(e) => updateFilter(filter.id, e.target.value)}
                      placeholder={filter.placeholder}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    />
                  )}

                  {filter.type === 'boolean' && (
                    <select
                      value={activeFilters[filter.id] || ''}
                      onChange={(e) => updateFilter(filter.id, e.target.value === 'true')}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                    >
                      <option value="">Any</option>
                      <option value="true">Yes</option>
                      <option value="false">No</option>
                    </select>
                  )}

                  {activeFilters[filter.id] !== undefined && activeFilters[filter.id] !== '' && (
                    <button
                      onClick={() => removeFilter(filter.id)}
                      className="text-xs text-red-600 hover:text-red-700 dark:text-red-400 flex items-center"
                    >
                      <X className="w-3 h-3 mr-1" />
                      Remove filter
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Active Filters Display */}
      {activeFilterCount > 0 && (
        <div className="flex flex-wrap gap-2">
          {Object.entries(activeFilters).map(([filterId, value]) => {
            if (value === undefined || value === '' || value === null) return null;
            
            const filter = filters.find(f => f.id === filterId);
            if (!filter) return null;

            return (
              <div
                key={filterId}
                className="inline-flex items-center bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200 px-3 py-1 rounded-full text-sm"
              >
                <span>{filter.label}: {value.toString()}</span>
                <button
                  onClick={() => removeFilter(filterId)}
                  className="ml-2 text-purple-600 hover:text-purple-800 dark:text-purple-300 dark:hover:text-purple-100"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Saved Searches */}
      {savedSearches.length > 0 && (
        <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
          <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Saved Searches</h4>
          <div className="flex flex-wrap gap-2">
            {savedSearches.map((search, index) => (
              <button
                key={index}
                onClick={() => loadSavedSearch(search)}
                className="inline-flex items-center bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300 px-3 py-1 rounded hover:bg-gray-300 dark:hover:bg-gray-600 text-sm transition-colors"
              >
                <Star className="w-3 h-3 mr-1" />
                {search.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Export common filter configurations
export const projectFilters: SearchFilter[] = [
  {
    id: 'ai_platform',
    label: 'AI Platform',
    type: 'select',
    icon: Brain,
    options: [
      { value: 'mocha', label: 'Mocha' },
      { value: 'lovable', label: 'Lovable' },
      { value: 'bolt', label: 'Bolt' },
      { value: 'cursor', label: 'Cursor' },
      { value: 'claude', label: 'Claude' }
    ]
  },
  {
    id: 'status',
    label: 'Status',
    type: 'select',
    icon: CheckCircle,
    options: [
      { value: 'planning', label: 'Planning' },
      { value: 'development', label: 'Development' },
      { value: 'testing', label: 'Testing' },
      { value: 'deployed', label: 'Deployed' },
      { value: 'maintenance', label: 'Maintenance' }
    ]
  },
  {
    id: 'project_type',
    label: 'Project Type',
    type: 'select',
    icon: Tag,
    options: [
      { value: 'medical', label: 'Medical App' },
      { value: 'ecommerce', label: 'E-commerce' },
      { value: 'saas', label: 'SaaS Tool' },
      { value: 'web', label: 'Web App' },
      { value: 'mobile', label: 'Mobile App' },
      { value: 'ai', label: 'AI Tool' }
    ]
  },
  {
    id: 'completion_percentage',
    label: 'Min Completion %',
    type: 'number',
    icon: BarChart3,
    placeholder: '0-100'
  },
  {
    id: 'credits_used',
    label: 'Min Credits Used',
    type: 'number',
    icon: DollarSign,
    placeholder: 'Minimum credits'
  },
  {
    id: 'created_at',
    label: 'Created After',
    type: 'date',
    icon: Calendar
  }
];

export const projectSearchFields = [
  'project_name',
  'project_description',
  'ai_platform',
  'project_type',
  'features_completed',
  'features_pending',
  'known_bugs'
];
