export default function WhiteLabelCustomization() {
  return (
    <div className="text-center py-8">
      <h3 className="text-lg font-medium text-gray-900 mb-2">White Label Customization</h3>
      <p className="text-gray-500">Branding and customization features coming soon...</p>
    </div>
  );
}