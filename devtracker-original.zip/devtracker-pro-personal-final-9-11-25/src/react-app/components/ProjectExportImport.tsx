import React, { useState, useEffect } from 'react';
import { useAuth } from "@/shims/mocha-auth";
import DataService from "@/react-app/services/DataService";
import {
  Download,
  Upload,
  FileText,
  CheckCircle,
  AlertCircle,
  Database,
  ArrowRight
} from 'lucide-react';

interface ProjectExportImportProps {
  onImportComplete?: () => void;
}

const ProjectExportImport: React.FC<ProjectExportImportProps> = ({ onImportComplete }) => {
  const { user } = useAuth();
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'export' | 'import'>('export');
  const [exportStatus, setExportStatus] = useState<'idle' | 'exporting' | 'success' | 'error'>('idle');
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importPreview, setImportPreview] = useState<any[]>([]);
  const [importStatus, setImportStatus] = useState<'idle' | 'importing' | 'success' | 'error'>('idle');
  const [importMessage, setImportMessage] = useState<string>('');

  const dataService = DataService.getInstance();

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      setLoading(true);
      const data = await dataService.getProjects();
      setProjects(data);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const exportToJSON = () => {
    try {
      setExportStatus('exporting');
      const exportData = dataService.exportToJSON();
      
      const blob = new Blob([exportData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `devtracker-pro-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      setExportStatus('success');
      setTimeout(() => setExportStatus('idle'), 3000);
    } catch (error) {
      console.error('Export error:', error);
      setExportStatus('error');
      setTimeout(() => setExportStatus('idle'), 3000);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImportFile(file);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);
        
        if (parsed.projects && Array.isArray(parsed.projects)) {
          setImportPreview(parsed.projects);
          setImportMessage(`Found ${parsed.projects.length} projects in the file`);
        } else {
          setImportMessage('Invalid file format: No projects found');
        }
      } catch (error) {
        setImportMessage('Error reading file: Invalid JSON format');
      }
    };
    reader.readAsText(file);
  };

  const executeImport = async () => {
    if (!importFile) return;

    try {
      setImportStatus('importing');
      setLoading(true);

      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const content = e.target?.result as string;
          const result = await dataService.importFromJSON(content);
          
          if (result.success) {
            setImportStatus('success');
            setImportMessage(result.message);
            await fetchProjects(); // Refresh the projects list
            if (onImportComplete) {
              onImportComplete();
            }
          } else {
            setImportStatus('error');
            setImportMessage(result.message);
          }
        } catch (error) {
          setImportStatus('error');
          setImportMessage(`Import failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        } finally {
          setLoading(false);
          setTimeout(() => {
            setImportStatus('idle');
            setImportMessage('');
          }, 5000);
        }
      };
      reader.readAsText(importFile);
    } catch (error) {
      setImportStatus('error');
      setImportMessage(`Import failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      setLoading(false);
    }
  };

  const clearImport = () => {
    setImportFile(null);
    setImportPreview([]);
    setImportMessage('');
    setImportStatus('idle');
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="flex items-center space-x-2 mb-6">
        <Database className="w-5 h-5 text-purple-600" />
        <h3 className="text-lg font-semibold text-gray-900">Data Import/Export</h3>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg">
        <button
          onClick={() => setActiveTab('export')}
          className={`flex-1 py-2 px-4 text-sm font-medium rounded-md transition-colors ${
            activeTab === 'export'
              ? 'bg-white text-purple-700 shadow-sm'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <Download className="w-4 h-4 inline mr-2" />
          Export Data
        </button>
        <button
          onClick={() => setActiveTab('import')}
          className={`flex-1 py-2 px-4 text-sm font-medium rounded-md transition-colors ${
            activeTab === 'import'
              ? 'bg-white text-purple-700 shadow-sm'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <Upload className="w-4 h-4 inline mr-2" />
          Import Data
        </button>
      </div>

      {/* Export Tab */}
      {activeTab === 'export' && (
        <div className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">Export Your DevTracker Pro Data</h4>
            <p className="text-sm text-blue-700 mb-3">
              Download all your projects, AI assistants, deployment events, and settings as a JSON file.
            </p>
            <div className="text-sm text-blue-600">
              <strong>Includes:</strong> {projects.length} projects, AI assistant configurations, deployment history, and settings
            </div>
          </div>

          <button
            onClick={exportToJSON}
            disabled={loading || exportStatus === 'exporting'}
            className="w-full btn-primary flex items-center justify-center space-x-2"
          >
            {exportStatus === 'exporting' ? (
              <>
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                <span>Exporting...</span>
              </>
            ) : exportStatus === 'success' ? (
              <>
                <CheckCircle className="w-4 h-4" />
                <span>Exported Successfully!</span>
              </>
            ) : exportStatus === 'error' ? (
              <>
                <AlertCircle className="w-4 h-4" />
                <span>Export Failed</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Export to JSON</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Import Tab */}
      {activeTab === 'import' && (
        <div className="space-y-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="font-medium text-green-900 mb-2">Import Your Saved Data</h4>
            <p className="text-sm text-green-700">
              Upload a JSON file exported from DevTracker Pro to restore your projects and settings.
            </p>
          </div>

          {!importFile ? (
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <FileText className="w-8 h-8 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600 mb-3">Choose a JSON file to import</p>
              <input
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload"
              />
              <label
                htmlFor="file-upload"
                className="btn-primary cursor-pointer"
              >
                <Upload className="w-4 h-4 mr-2" />
                Select File
              </label>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-gray-900">{importFile.name}</span>
                  <button
                    onClick={clearImport}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    ×
                  </button>
                </div>
                {importMessage && (
                  <p className="text-sm text-gray-600">{importMessage}</p>
                )}
              </div>

              {importPreview.length > 0 && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h5 className="font-medium text-gray-900 mb-2">Preview ({importPreview.length} projects)</h5>
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {importPreview.slice(0, 5).map((project, index) => (
                      <div key={index} className="text-sm text-gray-600 flex items-center">
                        <ArrowRight className="w-3 h-3 mr-2" />
                        {project.project_name || `Project ${index + 1}`}
                      </div>
                    ))}
                    {importPreview.length > 5 && (
                      <div className="text-sm text-gray-500">
                        ...and {importPreview.length - 5} more projects
                      </div>
                    )}
                  </div>
                </div>
              )}

              <button
                onClick={executeImport}
                disabled={loading || importStatus === 'importing' || importPreview.length === 0}
                className="w-full btn-primary flex items-center justify-center space-x-2"
              >
                {importStatus === 'importing' ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                    <span>Importing...</span>
                  </>
                ) : importStatus === 'success' ? (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    <span>Import Successful!</span>
                  </>
                ) : importStatus === 'error' ? (
                  <>
                    <AlertCircle className="w-4 h-4" />
                    <span>Import Failed</span>
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4" />
                    <span>Import Data</span>
                  </>
                )}
              </button>

              {importMessage && importStatus !== 'idle' && (
                <div className={`p-3 rounded-lg text-sm ${
                  importStatus === 'success' 
                    ? 'bg-green-50 text-green-700 border border-green-200'
                    : importStatus === 'error'
                    ? 'bg-red-50 text-red-700 border border-red-200'
                    : 'bg-blue-50 text-blue-700 border border-blue-200'
                }`}>
                  {importMessage}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ProjectExportImport;