# Requested UI Theme Change — SPEC v2 (White Cards + 3D Elevation + Slight Gray Background)

**Goal:** Keep the white-card look, but add a subtle 3D elevation and use a very light gray background behind the cards.

## Must-Haves
1. Background uses a light gray: **#F6F7F9**.
2. Cards: white surface, 1px #E5E7EB border, 14px radius. No solid/gradient fills.
3. Cards have subtle elevation (shadow): 
   - Default: `0 6px 18px rgba(17,24,39,0.06), 0 1px 2px rgba(17,24,39,0.05)`
   - Hover/focus: `0 10px 24px rgba(17,24,39,0.08), 0 2px 4px rgba(17,24,39,0.06)` with a 2px upward shift.
4. Accent color limited to chips, thin 8px progress bars, and the primary CTA.
5. Typography: Inter/system UI; #111827 text; #6B7280 muted.

## Implementation Notes
- CSS ready to use in `lovable-theme.v2.css`.
- `reference.v2.html` shows the expected look with elevation on hover.