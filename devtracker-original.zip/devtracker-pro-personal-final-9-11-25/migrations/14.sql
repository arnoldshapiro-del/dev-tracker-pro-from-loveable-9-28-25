
INSERT INTO user_preferences (
  user_id, default_ai_platform, preferred_deployment, 
  credit_budget_monthly, github_token, netlify_token
) VALUES (
  'demo-user', 'mocha', 'netlify', 100, 
  'demo_github_token_for_testing', 'demo_netlify_token_for_testing'
);
