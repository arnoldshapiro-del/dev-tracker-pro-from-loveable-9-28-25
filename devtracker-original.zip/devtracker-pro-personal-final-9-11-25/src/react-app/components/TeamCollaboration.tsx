import React, { useState, useEffect } from 'react';
import { useAuth } from "@/shims/mocha-auth";
import DataService from "@/react-app/services/DataService";
import { 
  Users, 
  Plus, 
  Crown, 
  Shield, 
  UserPlus, 
  Settings,
  Trash2,
  Copy,
  Check,
  Mail,
  User,
  AlertCircle,
  Star
} from "lucide-react";

interface Team {
  id: number;
  team_name: string;
  team_description?: string;
  team_code: string;
  is_public: boolean;
  max_members: number;
  subscription_tier: string;
  member_count?: number;
  user_role?: string;
  created_at: string;
}

interface TeamMember {
  id: number;
  team_id: number;
  user_id: string;
  member_email: string;
  role: string;
  permissions: string[];
  invite_status: string;
  joined_at?: string;
}

interface TeamCollaborationProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function TeamCollaboration({ isOpen, onClose }: TeamCollaborationProps) {
  const { user } = useAuth();
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'my-teams' | 'join-team' | 'create-team'>('my-teams');
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [copied, setCopied] = useState(false);

  const [createForm, setCreateForm] = useState({
    team_name: '',
    team_description: '',
    is_public: false,
    max_members: 5
  });

  const [joinForm, setJoinForm] = useState({
    team_code: ''
  });

  const [inviteForm, setInviteForm] = useState({
    member_email: '',
    role: 'member'
  });

  useEffect(() => {
    if (isOpen && user) {
      fetchTeams();
    }
  }, [isOpen, user]);

  const fetchTeams = async () => {
    try {
      setLoading(true);
      // Mock teams data since this is not a core feature
      const mockTeams = [
        {
          id: 1,
          team_name: 'Development Team',
          team_description: 'Main development team for AI projects',
          team_code: 'DEV001',
          is_public: false,
          max_members: 10,
          subscription_tier: 'pro',
          member_count: 3,
          user_role: 'owner',
          created_at: new Date().toISOString()
        }
      ];
      setTeams(mockTeams);
    } catch (error) {
      console.error('Error fetching teams:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTeam = async () => {
    if (!createForm.team_name.trim()) return;

    try {
      // Mock team creation
      const newTeam = {
        id: Date.now(),
        team_name: createForm.team_name,
        team_description: createForm.team_description,
        team_code: `TEAM${Date.now()}`,
        is_public: createForm.is_public,
        max_members: createForm.max_members,
        subscription_tier: 'free',
        member_count: 1,
        user_role: 'owner',
        created_at: new Date().toISOString()
      };
      
      setTeams(prev => [...prev, newTeam]);
      setCreateForm({
        team_name: '',
        team_description: '',
        is_public: false,
        max_members: 5
      });
      setActiveTab('my-teams');
    } catch (error) {
      console.error('Error creating team:', error);
    }
  };

  const handleJoinTeam = async () => {
    if (!joinForm.team_code.trim()) return;

    try {
      // Mock team joining
      if (joinForm.team_code === 'DEV001') {
        alert('Successfully joined Development Team!');
        setJoinForm({ team_code: '' });
        setActiveTab('my-teams');
        fetchTeams();
      } else {
        alert('Team code not found');
      }
    } catch (error) {
      console.error('Error joining team:', error);
    }
  };

  const handleInviteMember = async () => {
    if (!inviteForm.member_email.trim() || !selectedTeam) return;

    try {
      // Mock member invitation
      alert(`Invitation sent to ${inviteForm.member_email} to join ${selectedTeam.team_name}!`);
      setInviteForm({ member_email: '', role: 'member' });
      setShowInviteModal(false);
      fetchTeams();
    } catch (error) {
      console.error('Error inviting member:', error);
    }
  };

  const copyTeamCode = (teamCode: string) => {
    navigator.clipboard.writeText(teamCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner': return <Crown className="w-4 h-4 text-yellow-500" />;
      case 'admin': return <Shield className="w-4 h-4 text-purple-500" />;
      case 'member': return <User className="w-4 h-4 text-blue-500" />;
      default: return <User className="w-4 h-4 text-gray-500" />;
    }
  };

  const getTierBadge = (tier: string) => {
    const colors = {
      free: 'bg-gray-100 text-gray-700',
      pro: 'bg-blue-100 text-blue-700',
      enterprise: 'bg-purple-100 text-purple-700'
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[tier as keyof typeof colors] || colors.free}`}>
        {tier.toUpperCase()}
      </span>
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Team Collaboration</h2>
              <p className="text-sm text-gray-600">Manage teams and collaborate on projects</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Trash2 className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-gray-200 px-6">
          <nav className="-mb-px flex space-x-8">
            {[
              { key: 'my-teams', label: 'My Teams', icon: Users },
              { key: 'join-team', label: 'Join Team', icon: UserPlus },
              { key: 'create-team', label: 'Create Team', icon: Plus }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.key
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'my-teams' && (
            <div className="space-y-6">
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
                </div>
              ) : teams.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No teams yet</h3>
                  <p className="text-gray-600 mb-6">Create a team or join an existing one to start collaborating</p>
                  <div className="flex justify-center space-x-3">
                    <button
                      onClick={() => setActiveTab('create-team')}
                      className="btn-primary"
                    >
                      Create Team
                    </button>
                    <button
                      onClick={() => setActiveTab('join-team')}
                      className="btn-secondary"
                    >
                      Join Team
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {teams.map((team) => (
                    <div key={team.id} className="card hover:shadow-lg transition-shadow">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
                            <Users className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="font-medium text-gray-900">{team.team_name}</h3>
                            <div className="flex items-center space-x-2">
                              {getRoleIcon(team.user_role || 'member')}
                              <span className="text-sm text-gray-500 capitalize">{team.user_role}</span>
                            </div>
                          </div>
                        </div>
                        {getTierBadge(team.subscription_tier)}
                      </div>

                      {team.team_description && (
                        <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                          {team.team_description}
                        </p>
                      )}

                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Members</span>
                          <span className="font-medium">{team.member_count || 0}/{team.max_members}</span>
                        </div>

                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Team Code</span>
                          <button
                            onClick={() => copyTeamCode(team.team_code)}
                            className="flex items-center space-x-1 text-blue-600 hover:text-blue-700"
                          >
                            <span className="font-mono">{team.team_code}</span>
                            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                          </button>
                        </div>

                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Visibility</span>
                          <span className="font-medium">
                            {team.is_public ? 'Public' : 'Private'}
                          </span>
                        </div>
                      </div>

                      <div className="flex space-x-2 mt-4 pt-4 border-t border-gray-100">
                        {(team.user_role === 'owner' || team.user_role === 'admin') && (
                          <button
                            onClick={() => {
                              setSelectedTeam(team);
                              setShowInviteModal(true);
                            }}
                            className="flex-1 btn-secondary text-sm"
                          >
                            <UserPlus className="w-4 h-4 mr-2" />
                            Invite
                          </button>
                        )}
                        <button className="flex-1 btn-secondary text-sm">
                          <Settings className="w-4 h-4 mr-2" />
                          Settings
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'join-team' && (
            <div className="max-w-md mx-auto">
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <UserPlus className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Join a Team</h3>
                <p className="text-gray-600">Enter the team code shared by your team leader</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Team Code
                  </label>
                  <input
                    type="text"
                    value={joinForm.team_code}
                    onChange={(e) => setJoinForm({ ...joinForm, team_code: e.target.value.toUpperCase() })}
                    placeholder="Enter team code (e.g., TEAM-ABC123)"
                    className="input-field font-mono"
                    maxLength={10}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Team codes are case-insensitive and typically 6-10 characters
                  </p>
                </div>

                <button
                  onClick={handleJoinTeam}
                  disabled={!joinForm.team_code.trim()}
                  className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Join Team
                </button>
              </div>

              <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                <div className="flex items-start space-x-3">
                  <AlertCircle className="w-5 h-5 text-blue-500 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium text-blue-900">Don't have a team code?</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      Ask your team leader to share the team code with you, or create your own team to start collaborating.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'create-team' && (
            <div className="max-w-2xl mx-auto">
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Plus className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Create New Team</h3>
                <p className="text-gray-600">Set up a new team to collaborate on projects</p>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Team Name *
                  </label>
                  <input
                    type="text"
                    value={createForm.team_name}
                    onChange={(e) => setCreateForm({ ...createForm, team_name: e.target.value })}
                    placeholder="e.g., AI Development Squad"
                    className="input-field"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    value={createForm.team_description}
                    onChange={(e) => setCreateForm({ ...createForm, team_description: e.target.value })}
                    placeholder="Brief description of what this team does..."
                    rows={3}
                    className="input-field resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Max Members
                    </label>
                    <select
                      value={createForm.max_members}
                      onChange={(e) => setCreateForm({ ...createForm, max_members: Number(e.target.value) })}
                      className="input-field"
                    >
                      <option value={3}>3 members</option>
                      <option value={5}>5 members</option>
                      <option value={10}>10 members</option>
                      <option value={25}>25 members</option>
                      <option value={50}>50 members</option>
                    </select>
                  </div>

                  <div className="flex items-center pt-8">
                    <label className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={createForm.is_public}
                        onChange={(e) => setCreateForm({ ...createForm, is_public: e.target.checked })}
                        className="rounded border-gray-300"
                      />
                      <span className="text-sm font-medium text-gray-700">
                        Public Team
                      </span>
                    </label>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <Star className="w-5 h-5 text-yellow-500 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Free Plan Features</h4>
                      <ul className="text-sm text-gray-600 mt-1 space-y-1">
                        <li>• Up to 5 team members</li>
                        <li>• Shared project access</li>
                        <li>• Basic collaboration tools</li>
                        <li>• Team activity notifications</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleCreateTeam}
                  disabled={!createForm.team_name.trim()}
                  className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Create Team
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Invite Member Modal */}
        {showInviteModal && selectedTeam && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl shadow-xl max-w-md w-full">
              <div className="flex items-center justify-between p-6 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">Invite Member</h3>
                <button
                  onClick={() => setShowInviteModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Trash2 className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={inviteForm.member_email}
                    onChange={(e) => setInviteForm({ ...inviteForm, member_email: e.target.value })}
                    placeholder="colleague@example.com"
                    className="input-field"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Role
                  </label>
                  <select
                    value={inviteForm.role}
                    onChange={(e) => setInviteForm({ ...inviteForm, role: e.target.value })}
                    className="input-field"
                  >
                    <option value="member">Member - Can view and edit shared projects</option>
                    <option value="admin">Admin - Can manage team settings and members</option>
                  </select>
                </div>

                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-sm text-blue-700">
                    An invitation email will be sent to this address with instructions to join "{selectedTeam.team_name}".
                  </p>
                </div>
              </div>

              <div className="flex space-x-3 p-6 border-t border-gray-200">
                <button
                  onClick={() => setShowInviteModal(false)}
                  className="flex-1 btn-secondary"
                >
                  Cancel
                </button>
                <button
                  onClick={handleInviteMember}
                  disabled={!inviteForm.member_email.trim()}
                  className="flex-1 btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Send Invite
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
