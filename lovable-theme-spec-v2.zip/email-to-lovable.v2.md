Hi Lovable Team—

Please update my project to the **white-card style with subtle 3D elevation** (not the solid/gradient tiles). I’ve attached a new ZIP with everything needed.

**Changes from before**
- Background should be a very light gray: #F6F7F9
- Cards must appear slightly elevated above the background (soft shadow):
  • Default shadow: 0 6px 18px rgba(17,24,39,0.06), 0 1px 2px rgba(17,24,39,0.05)
  • Hover/focus: 0 10px 24px rgba(17,24,39,0.08), 0 2px 4px rgba(17,24,39,0.06) and shift up by 2px
- Keep cards white with a 1px #E5E7EB border and 14px radius.
- Keep color only in chips, thin 8px rounded progress bars, and the primary CTA.

Everything is packaged in `lovable-theme-spec-v2.zip`:
- `lovable-theme.v2.css` (drop-in CSS)
- `reference.v2.html` (visual reference)
- `definition-of-done.v2.md` (acceptance criteria)

**Definition of Done:** The UI matches the elevated white-card look (gray background, white cards with subtle shadow as specified) and the example in `reference.v2.html`. Please share a screenshot to confirm.

Thank you!