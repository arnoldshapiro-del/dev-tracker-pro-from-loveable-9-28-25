import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/shims/mocha-auth";
import DevDashboard from "@/react-app/pages/DevDashboard";
import Projects from "@/react-app/pages/Projects";
import AIAssistantComparison from "@/react-app/pages/AIAssistantComparison";
import DeploymentGuide from "@/react-app/pages/DeploymentGuide";
import Reporting from "@/react-app/pages/Reporting";
import Security from "@/react-app/pages/Security";
import Mobile from "@/react-app/pages/Mobile";
import Workflows from "@/react-app/pages/Workflows";
import Integrations from "@/react-app/pages/Integrations";
import Help from "@/react-app/pages/Help";
import SetupGuide from "@/react-app/pages/SetupGuide";
import TeamCollaboration from "@/react-app/pages/TeamCollaboration";
import TestDeployment from "@/react-app/pages/TestDeployment";
import TokenSettings from "@/react-app/pages/TokenSettings";
import TokenTest from "@/react-app/pages/TokenTest";
import WhiteLabel from "@/react-app/pages/WhiteLabel";

export default function App() {
  
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          {/* Setup Guide as default */}
          <Route path="/" element={<SetupGuide />} />
          
          {/* Main pages */}
          <Route path="/dashboard" element={<DevDashboard />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/ai-assistants" element={<AIAssistantComparison />} />
          <Route path="/deployment" element={<DeploymentGuide />} />
          <Route path="/analytics" element={<Reporting />} />
          <Route path="/security" element={<Security />} />
          <Route path="/mobile" element={<Mobile />} />
          <Route path="/workflows" element={<Workflows />} />
          <Route path="/integrations" element={<Integrations />} />
          <Route path="/help" element={<Help />} />
          <Route path="/setup" element={<SetupGuide />} />
          <Route path="/team" element={<TeamCollaboration />} />
          
          {/* Additional pages */}
          <Route path="/test-deployment" element={<TestDeployment />} />
          <Route path="/token-settings" element={<TokenSettings />} />
          <Route path="/token-test" element={<TokenTest />} />
          <Route path="/white-label" element={<WhiteLabel />} />
          
          {/* Catch-all redirect */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}