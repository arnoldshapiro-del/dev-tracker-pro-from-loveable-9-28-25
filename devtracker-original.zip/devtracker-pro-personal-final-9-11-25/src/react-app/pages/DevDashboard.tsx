import { useAuth } from "@/shims/mocha-auth";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/react-app/components/Layout";
import { 
  Code2,
  Folder,
  TrendingUp,
  Users,
  Plus,
  BarChart3,
  ChevronRight,
  GitBranch,
  Zap,
  AlertCircle,
  CheckCircle,
  Clock,
  DollarSign,
  ExternalLink,
  Target
} from "lucide-react";

interface ProjectType {
  id: number;
  project_name: string;
  project_description?: string;
  ai_platform: string;
  project_type: string;
  status: string;
  completion_percentage: number;
  current_version: string;
  github_repo_url?: string;
  netlify_url?: string;
  vercel_url?: string;
  credits_used: number;
  credits_remaining: number;
  created_at: string;
  updated_at: string;
}

interface DevDashboardStats {
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  totalCreditsUsed: number;
  creditsRemaining: number;
  averageCompletionTime: number;
  successRate: number;
  deployedProjects: number;
}

export default function DevDashboard() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState<ProjectType[]>([]);
  const [stats, setStats] = useState<DevDashboardStats>({
    totalProjects: 0,
    activeProjects: 0,
    completedProjects: 0,
    totalCreditsUsed: 0,
    creditsRemaining: 0,
    averageCompletionTime: 0,
    successRate: 0,
    deployedProjects: 0
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/setup');
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Use mock data for personal build (no backend)
      const mockProjects: ProjectType[] = [
        {
          id: 1,
          project_name: "AI Chatbot Assistant",
          project_description: "An intelligent chatbot for customer support",
          ai_platform: "OpenAI",
          project_type: "Web Application",
          status: "completed",
          completion_percentage: 100,
          current_version: "v1.0.0",
          github_repo_url: "https://github.com/example/chatbot",
          netlify_url: "https://my-chatbot.netlify.app",
          credits_used: 150,
          credits_remaining: 850,
          created_at: "2024-01-15",
          updated_at: "2024-02-01"
        },
        {
          id: 2,
          project_name: "Task Management Dashboard",
          project_description: "A comprehensive project management tool",
          ai_platform: "Claude",
          project_type: "Web Application", 
          status: "in_progress",
          completion_percentage: 75,
          current_version: "v0.8.0",
          github_repo_url: "https://github.com/example/task-manager",
          credits_used: 200,
          credits_remaining: 300,
          created_at: "2024-02-10",
          updated_at: "2024-02-20"
        },
        {
          id: 3,
          project_name: "Weather Prediction API",
          project_description: "ML-powered weather forecasting service",
          ai_platform: "GitHub Copilot",
          project_type: "API",
          status: "planning",
          completion_percentage: 25,
          current_version: "v0.1.0",
          credits_used: 50,
          credits_remaining: 450,
          created_at: "2024-02-25",
          updated_at: "2024-02-25"
        }
      ];

      setProjects(mockProjects);

      // Calculate stats
      const totalProjects = mockProjects.length;
      const activeProjects = mockProjects.filter((p: ProjectType) => 
        p.status === 'in_progress' || p.status === 'planning'
      ).length;
      const completedProjects = mockProjects.filter((p: ProjectType) => 
        p.status === 'completed'
      ).length;
      const deployedProjects = mockProjects.filter((p: ProjectType) => 
        p.netlify_url || p.vercel_url || p.github_repo_url
      ).length;
      const totalCreditsUsed = mockProjects.reduce((sum: number, p: ProjectType) => 
        sum + (p.credits_used || 0), 0
      );
      const creditsRemaining = mockProjects.reduce((sum: number, p: ProjectType) => 
        sum + (p.credits_remaining || 0), 0
      );

      setStats({
        totalProjects,
        activeProjects,
        completedProjects,
        totalCreditsUsed,
        creditsRemaining,
        averageCompletionTime: 2.5,
        successRate: completedProjects > 0 ? (completedProjects / totalProjects) * 100 : 0,
        deployedProjects
      });

    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'planning': return 'bg-blue-100 text-blue-800';
      case 'in_progress': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'deployed': return 'bg-purple-100 text-purple-800';
      case 'paused': return 'bg-gray-100 text-gray-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPlatformColor = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'mocha': return 'bg-purple-100 text-purple-800';
      case 'claude': return 'bg-orange-100 text-orange-800';
      case 'chatgpt': return 'bg-green-100 text-green-800';
      case 'github copilot': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getProjectDeployedUrl = (project: ProjectType): string | null => {
    // Priority order for deployment URLs
    const urls = [
      (project as any).mocha_published_url,
      project.netlify_url,
      project.vercel_url,
      project.github_repo_url
    ];
    
    for (const url of urls) {
      if (url && url.trim() !== '') {
        return url.trim();
      }
    }
    
    return null;
  };

  if (isPending || loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-full">
          <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full"></div>
        </div>
      </Layout>
    );
  }

  if (!user) return null;

  return (
    <Layout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Welcome back, {user.google_user_data?.name?.split(' ')[0] || 'Developer'}
            </h1>
            <p className="text-gray-600">
              {stats.totalProjects} projects • {stats.activeProjects} active • {stats.creditsRemaining} credits remaining
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => navigate('/projects?action=add')}
              className="btn-primary flex items-center space-x-2"
            >
              <Plus className="w-4 h-4" />
              <span>New Project</span>
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-gradient-to-r from-purple-500 to-blue-600 rounded-lg p-4 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-xs font-medium">Total Projects</p>
                <p className="text-xl font-bold">{stats.totalProjects}</p>
              </div>
              <Folder className="w-6 h-6 text-purple-200" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg p-4 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-xs font-medium">Active Projects</p>
                <p className="text-xl font-bold">{stats.activeProjects}</p>
              </div>
              <Code2 className="w-6 h-6 text-green-200" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg p-4 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-xs font-medium">Success Rate</p>
                <p className="text-xl font-bold">{Math.round(stats.successRate)}%</p>
              </div>
              <Target className="w-6 h-6 text-blue-200" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-lg p-4 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100 text-xs font-medium">Credits Used</p>
                <p className="text-xl font-bold">{stats.totalCreditsUsed}</p>
              </div>
              <DollarSign className="w-6 h-6 text-orange-200" />
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={() => navigate('/projects?action=add')}
            className="p-6 bg-white border border-gray-200 rounded-lg hover:border-purple-300 hover:shadow-sm transition-all group"
          >
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                <Plus className="w-6 h-6 text-purple-600" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">Start New Project</h3>
                <p className="text-sm text-gray-600">Create a new AI development project</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => navigate('/ai-assistants')}
            className="p-6 bg-white border border-gray-200 rounded-lg hover:border-blue-300 hover:shadow-sm transition-all group"
          >
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-200 transition-colors">
                <Code2 className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">Compare AI Assistants</h3>
                <p className="text-sm text-gray-600">Analyze performance across platforms</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => navigate('/deployment')}
            className="p-6 bg-white border border-gray-200 rounded-lg hover:border-green-300 hover:shadow-sm transition-all group"
          >
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center group-hover:bg-green-200 transition-colors">
                <Zap className="w-6 h-6 text-green-600" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">Deploy Projects</h3>
                <p className="text-sm text-gray-600">Manage deployments and publishing</p>
              </div>
            </div>
          </button>
        </div>

        {/* Recent Projects and Platform Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Projects */}
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center">
                <Folder className="w-5 h-5 mr-2 text-purple-600" />
                Recent Projects
              </h2>
              <button
                onClick={() => navigate('/projects')}
                className="text-purple-600 hover:text-purple-700 text-sm flex items-center space-x-1"
              >
                <span>View All</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {projects.length === 0 ? (
              <div className="text-center py-8">
                <Folder className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <h3 className="text-sm font-medium text-gray-900 mb-1">No projects yet</h3>
                <p className="text-sm text-gray-500 mb-4">Create your first AI development project</p>
                <button
                  onClick={() => navigate('/projects?action=add')}
                  className="btn-primary btn-sm"
                >
                  Add Project
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {projects.slice(0, 5).map((project) => (
                  <div key={project.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                        <Code2 className="w-4 h-4 text-purple-600" />
                      </div>
                      <div>
                        <button
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            const deployedUrl = getProjectDeployedUrl(project);
                            if (deployedUrl) {
                              window.open(deployedUrl, '_blank', 'noopener,noreferrer');
                            } else {
                              alert(`No deployed URL found for ${project.project_name}`);
                            }
                          }}
                          className="font-medium text-gray-900 hover:text-purple-600 transition-colors cursor-pointer underline decoration-transparent hover:decoration-purple-600"
                          title={`Click to open deployed ${project.project_name}`}
                        >
                          {project.project_name}
                        </button>
                        <div className="flex items-center space-x-2 text-xs text-gray-500">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPlatformColor(project.ai_platform)}`}>
                            {project.ai_platform}
                          </span>
                          <span>•</span>
                          <span>{project.completion_percentage}% complete</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {project.github_repo_url && (
                        <ExternalLink className="w-4 h-4 text-gray-400" />
                      )}
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(project.status)}`}>
                        {project.status}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Platform Performance */}
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-blue-600" />
                Platform Performance
              </h2>
              <button
                onClick={() => navigate('/ai-assistants')}
                className="text-blue-600 hover:text-blue-700 text-sm flex items-center space-x-1"
              >
                <span>View Details</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                    <Code2 className="w-4 h-4 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Mocha</p>
                    <p className="text-xs text-gray-500">Full-stack development</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-purple-600">95%</p>
                  <p className="text-xs text-gray-500">Success rate</p>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <GitBranch className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Claude</p>
                    <p className="text-xs text-gray-500">Code analysis</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-green-600">88%</p>
                  <p className="text-xs text-gray-500">Success rate</p>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <Users className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">ChatGPT</p>
                    <p className="text-xs text-gray-500">Feature development</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-blue-600">82%</p>
                  <p className="text-xs text-gray-500">Success rate</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Development Metrics */}
        <div className="card">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 text-green-600" />
            Development Metrics
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600 mb-1">{stats.averageCompletionTime}h</div>
              <div className="text-sm text-purple-800">Avg Completion</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600 mb-1">{stats.deployedProjects}</div>
              <div className="text-sm text-green-800">Deployed</div>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600 mb-1">{stats.creditsRemaining}</div>
              <div className="text-sm text-blue-800">Credits Left</div>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600 mb-1">98%</div>
              <div className="text-sm text-orange-800">Uptime</div>
            </div>
          </div>
        </div>

        {/* Quick Navigation Footer */}
        <div className="flex items-center justify-center space-x-4 pt-4">
          <button
            onClick={() => navigate('/projects')}
            className="btn-secondary flex items-center space-x-2"
          >
            <Folder className="w-4 h-4" />
            <span>Manage Projects</span>
          </button>
          <button
            onClick={() => navigate('/ai-assistants')}
            className="btn-secondary flex items-center space-x-2"
          >
            <Code2 className="w-4 h-4" />
            <span>AI Assistants</span>
          </button>
          <button
            onClick={() => navigate('/analytics')}
            className="btn-secondary flex items-center space-x-2"
          >
            <BarChart3 className="w-4 h-4" />
            <span>Analytics</span>
          </button>
        </div>
      </div>
    </Layout>
  );
}
