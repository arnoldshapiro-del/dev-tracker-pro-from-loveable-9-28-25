
DELETE FROM user_preferences WHERE user_id = 'demo-user';
