// Shim to remove dependency on @getmocha/users-service for personal/local use
import { ReactNode } from "react";

export type User = { 
  id: string; 
  email?: string; 
  name?: string;
  google_user_data?: {
    name?: string;
    email?: string;
  };
};

export function useAuth() {
  const user: User = { 
    id: "local-user", 
    email: "demo@devtracker.pro", 
    name: "Demo User",
    google_user_data: {
      name: "Demo User",
      email: "demo@devtracker.pro"
    }
  };
  return { user, isAuthenticated: true, isPending: false };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  return children as any;
}
