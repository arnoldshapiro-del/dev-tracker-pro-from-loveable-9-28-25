
# DevTracker Pro

This project was separated from a combined Mocha app that contained two apps behind a toggle.
You're looking at the **DevTracker Pro** portion. The separation was done heuristically by scanning
file paths and keywords, then copying shared code into each app.

## Getting Started

1. Install Node.js 18+.
2. Install deps:
   ```
   npm install
   ```
3. Development:
   ```
   npm run dev
   ```
4. Build:
   ```
   npm run build
   ```
5. Preview (if Vite-based):
   ```
   npm run preview
   ```

> If you used Hono/Cloudflare for APIs, deploy the server portion with Cloudflare Workers (Wrangler) or use the Hono Netlify adapter.

## Environment Variables

Create a `.env` by copying `.env.sample` and filling values. Review any references to environment variables
in `src/` and `server`/`api` folders.

## Notes & Next Steps

- Some files may still be shared between the two apps. If something is missing at build time, check the companion app and move the needed component into `src/shared/`.
- If you see Mocha-specific SDK references, replace them with your chosen services (e.g., Supabase for DB, your auth provider, Twilio for SMS).
- See `/separation-report/classification.csv` (separate download) for a full list of how files were classified.


## Personal-Use Build (no backend, no Mocha/Twilio)

This variant removes Mocha auth and Workers. Data persists locally in your browser (localStorage).
- No secrets required
- Netlify static hosting is sufficient
- To back up your data: use the app's Export button (JSON) and keep a copy

### Quick Start
```
npm install
npm run dev
npm run build
```
Deploy the `dist/` folder to Netlify by connecting your GitHub repo.
