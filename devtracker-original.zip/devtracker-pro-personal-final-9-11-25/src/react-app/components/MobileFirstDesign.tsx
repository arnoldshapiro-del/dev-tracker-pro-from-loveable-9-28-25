export default function MobileFirstDesign() {
  return (
    <div className="text-center py-8">
      <h3 className="text-lg font-medium text-gray-900 mb-2">Mobile First Design</h3>
      <p className="text-gray-500">Mobile optimization features coming soon...</p>
    </div>
  );
}