import React, { useState, useEffect } from 'react';
import { useAuth } from "@/shims/mocha-auth";
import DataService from "@/react-app/services/DataService";
import { 
  Bell, 
  BellOff, 
  Check, 
  CheckCheck, 
  Trash2, 
  Filter,
  Settings,
  X,
  AlertTriangle,
  Info,
  CheckCircle,
  Clock,
  Users,
  GitBranch,
  Zap,
  Mail,
  Smartphone,
  MessageSquare
} from "lucide-react";

interface Notification {
  id: number;
  user_id: string;
  notification_type: string;
  title: string;
  message: string;
  action_url?: string;
  is_read: boolean;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  category: string;
  metadata: any;
  expires_at?: string;
  created_at: string;
}

interface NotificationPreferences {
  id?: number;
  user_id: string;
  email_notifications: boolean;
  push_notifications: boolean;
  sms_notifications: boolean;
  team_activity: boolean;
  project_updates: boolean;
  deployment_alerts: boolean;
  credit_warnings: boolean;
  quiet_hours_start: string;
  quiet_hours_end: string;
  timezone: string;
}

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function NotificationCenter({ isOpen, onClose }: NotificationCenterProps) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [preferences, setPreferences] = useState<NotificationPreferences | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'notifications' | 'preferences'>('notifications');
  const [filter, setFilter] = useState<'all' | 'unread' | 'important'>('all');
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (isOpen && user) {
      fetchNotifications();
      fetchPreferences();
    }
  }, [isOpen, user]);

  useEffect(() => {
    const unread = notifications.filter(n => !n.is_read).length;
    setUnreadCount(unread);
  }, [notifications]);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const dataService = DataService.getInstance();
      const data = await dataService.getNotifications();
      setNotifications(data as Notification[]);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPreferences = async () => {
    try {
      // Mock preferences data
      const mockPreferences = {
        id: 1,
        user_id: user?.id || 'local-user',
        email_notifications: true,
        push_notifications: true,
        sms_notifications: false,
        team_activity: true,
        project_updates: true,
        deployment_alerts: true,
        credit_warnings: true,
        quiet_hours_start: '22:00',
        quiet_hours_end: '08:00',
        timezone: 'UTC'
      };
      setPreferences(mockPreferences);
    } catch (error) {
      console.error('Error fetching preferences:', error);
    }
  };

  const markAsRead = async (notificationId: number) => {
    try {
      // Update local state immediately
      setNotifications(prev => 
        prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
      );
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      // Update local state immediately
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  const deleteNotification = async (notificationId: number) => {
    try {
      // Update local state immediately
      setNotifications(prev => prev.filter(n => n.id !== notificationId));
    } catch (error) {
      console.error('Error deleting notification:', error);
    }
  };

  const updatePreferences = async () => {
    if (!preferences) return;

    try {
      // Mock preferences update
      alert('Preferences updated successfully!');
    } catch (error) {
      console.error('Error updating preferences:', error);
    }
  };

  const getNotificationIcon = (type: string, priority: string) => {
    const iconClass = priority === 'urgent' ? 'text-red-500' : 
                     priority === 'high' ? 'text-orange-500' : 
                     priority === 'normal' ? 'text-blue-500' : 'text-gray-500';

    switch (type) {
      case 'team_activity': return <Users className={`w-5 h-5 ${iconClass}`} />;
      case 'project_update': return <GitBranch className={`w-5 h-5 ${iconClass}`} />;
      case 'deployment': return <Zap className={`w-5 h-5 ${iconClass}`} />;
      case 'credit_warning': return <AlertTriangle className={`w-5 h-5 ${iconClass}`} />;
      case 'system': return <Settings className={`w-5 h-5 ${iconClass}`} />;
      default: return <Info className={`w-5 h-5 ${iconClass}`} />;
    }
  };

  const getPriorityBadge = (priority: string) => {
    const colors = {
      urgent: 'bg-red-100 text-red-700 border-red-200',
      high: 'bg-orange-100 text-orange-700 border-orange-200',
      normal: 'bg-blue-100 text-blue-700 border-blue-200',
      low: 'bg-gray-100 text-gray-700 border-gray-200'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${colors[priority as keyof typeof colors]}`}>
        {priority.toUpperCase()}
      </span>
    );
  };

  const filteredNotifications = notifications.filter(notification => {
    if (filter === 'unread') return !notification.is_read;
    if (filter === 'important') return notification.priority === 'high' || notification.priority === 'urgent';
    return true;
  });

  const getTimeAgo = (dateString: string) => {
    const now = new Date();
    const date = new Date(dateString);
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Bell className="w-6 h-6 text-white" />
              </div>
              {unreadCount > 0 && (
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </div>
              )}
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Notification Center</h2>
              <p className="text-sm text-gray-600">
                {unreadCount} unread notifications
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-gray-200 px-6">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('notifications')}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                activeTab === 'notifications'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Bell className="w-4 h-4" />
              <span>Notifications</span>
              {unreadCount > 0 && (
                <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                  {unreadCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('preferences')}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                activeTab === 'preferences'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>Preferences</span>
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'notifications' && (
            <div className="space-y-6">
              {/* Controls */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Filter className="w-5 h-5 text-gray-400" />
                  <select
                    value={filter}
                    onChange={(e) => setFilter(e.target.value as any)}
                    className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="all">All notifications</option>
                    <option value="unread">Unread only</option>
                    <option value="important">Important only</option>
                  </select>
                </div>
                
                <div className="flex items-center space-x-2">
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllAsRead}
                      className="btn-secondary text-sm flex items-center space-x-2"
                    >
                      <CheckCheck className="w-4 h-4" />
                      <span>Mark all read</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Notifications List */}
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
                </div>
              ) : filteredNotifications.length === 0 ? (
                <div className="text-center py-12">
                  <BellOff className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {filter === 'unread' ? 'No unread notifications' : 
                     filter === 'important' ? 'No important notifications' : 'No notifications'}
                  </h3>
                  <p className="text-gray-600">
                    {filter === 'all' ? 'You\'re all caught up!' : 'Check back later for updates'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`border rounded-lg p-4 transition-all hover:shadow-sm ${
                        notification.is_read ? 'bg-white border-gray-200' : 'bg-blue-50 border-blue-200'
                      }`}
                    >
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0 mt-1">
                          {getNotificationIcon(notification.notification_type, notification.priority)}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <h4 className={`text-sm font-medium ${
                                  notification.is_read ? 'text-gray-900' : 'text-gray-900'
                                }`}>
                                  {notification.title}
                                </h4>
                                {!notification.is_read && (
                                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                )}
                              </div>
                              
                              <p className={`text-sm ${
                                notification.is_read ? 'text-gray-600' : 'text-gray-700'
                              }`}>
                                {notification.message}
                              </p>
                              
                              <div className="flex items-center space-x-3 mt-2">
                                <span className="text-xs text-gray-500">
                                  {getTimeAgo(notification.created_at)}
                                </span>
                                {getPriorityBadge(notification.priority)}
                                <span className="text-xs text-gray-500 capitalize">
                                  {notification.category}
                                </span>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-2 ml-4">
                              {!notification.is_read && (
                                <button
                                  onClick={() => markAsRead(notification.id)}
                                  className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                                  title="Mark as read"
                                >
                                  <Check className="w-4 h-4" />
                                </button>
                              )}
                              
                              <button
                                onClick={() => deleteNotification(notification.id)}
                                className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                                title="Delete notification"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                          
                          {notification.action_url && (
                            <button
                              onClick={() => {
                                window.open(notification.action_url, '_blank');
                                if (!notification.is_read) markAsRead(notification.id);
                              }}
                              className="mt-2 text-sm text-blue-600 hover:text-blue-700 font-medium"
                            >
                              View Details →
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'preferences' && preferences && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Notification Preferences</h3>
                <p className="text-sm text-gray-600 mb-6">
                  Choose how and when you want to receive notifications
                </p>
              </div>

              {/* Notification Channels */}
              <div className="card">
                <h4 className="font-medium text-gray-900 mb-4 flex items-center space-x-2">
                  <MessageSquare className="w-5 h-5 text-blue-500" />
                  <span>Notification Channels</span>
                </h4>
                
                <div className="space-y-4">
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={preferences.email_notifications}
                      onChange={(e) => setPreferences({
                        ...preferences,
                        email_notifications: e.target.checked
                      })}
                      className="rounded border-gray-300"
                    />
                    <Mail className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-sm font-medium text-gray-900">Email notifications</span>
                      <p className="text-xs text-gray-500">Receive notifications via email</p>
                    </div>
                  </label>

                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={preferences.push_notifications}
                      onChange={(e) => setPreferences({
                        ...preferences,
                        push_notifications: e.target.checked
                      })}
                      className="rounded border-gray-300"
                    />
                    <Bell className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-sm font-medium text-gray-900">Push notifications</span>
                      <p className="text-xs text-gray-500">Browser and desktop notifications</p>
                    </div>
                  </label>

                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={preferences.sms_notifications}
                      onChange={(e) => setPreferences({
                        ...preferences,
                        sms_notifications: e.target.checked
                      })}
                      className="rounded border-gray-300"
                    />
                    <Smartphone className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-sm font-medium text-gray-900">SMS notifications</span>
                      <p className="text-xs text-gray-500">Critical alerts via text message</p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Notification Types */}
              <div className="card">
                <h4 className="font-medium text-gray-900 mb-4 flex items-center space-x-2">
                  <Filter className="w-5 h-5 text-purple-500" />
                  <span>Notification Types</span>
                </h4>
                
                <div className="space-y-4">
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={preferences.team_activity}
                      onChange={(e) => setPreferences({
                        ...preferences,
                        team_activity: e.target.checked
                      })}
                      className="rounded border-gray-300"
                    />
                    <Users className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-sm font-medium text-gray-900">Team activity</span>
                      <p className="text-xs text-gray-500">When team members join, leave, or update projects</p>
                    </div>
                  </label>

                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={preferences.project_updates}
                      onChange={(e) => setPreferences({
                        ...preferences,
                        project_updates: e.target.checked
                      })}
                      className="rounded border-gray-300"
                    />
                    <GitBranch className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-sm font-medium text-gray-900">Project updates</span>
                      <p className="text-xs text-gray-500">Status changes, feature completions, and milestones</p>
                    </div>
                  </label>

                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={preferences.deployment_alerts}
                      onChange={(e) => setPreferences({
                        ...preferences,
                        deployment_alerts: e.target.checked
                      })}
                      className="rounded border-gray-300"
                    />
                    <Zap className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-sm font-medium text-gray-900">Deployment alerts</span>
                      <p className="text-xs text-gray-500">Successful deployments and deployment failures</p>
                    </div>
                  </label>

                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={preferences.credit_warnings}
                      onChange={(e) => setPreferences({
                        ...preferences,
                        credit_warnings: e.target.checked
                      })}
                      className="rounded border-gray-300"
                    />
                    <AlertTriangle className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-sm font-medium text-gray-900">Credit warnings</span>
                      <p className="text-xs text-gray-500">When you're running low on credits</p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Quiet Hours */}
              <div className="card">
                <h4 className="font-medium text-gray-900 mb-4 flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-indigo-500" />
                  <span>Quiet Hours</span>
                </h4>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Start time
                    </label>
                    <input
                      type="time"
                      value={preferences.quiet_hours_start}
                      onChange={(e) => setPreferences({
                        ...preferences,
                        quiet_hours_start: e.target.value
                      })}
                      className="input-field"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      End time
                    </label>
                    <input
                      type="time"
                      value={preferences.quiet_hours_end}
                      onChange={(e) => setPreferences({
                        ...preferences,
                        quiet_hours_end: e.target.value
                      })}
                      className="input-field"
                    />
                  </div>
                </div>
                
                <p className="text-xs text-gray-500 mt-2">
                  No notifications will be sent during these hours, except for urgent alerts
                </p>
              </div>

              {/* Timezone */}
              <div className="card">
                <h4 className="font-medium text-gray-900 mb-4">Timezone</h4>
                <select
                  value={preferences.timezone}
                  onChange={(e) => setPreferences({
                    ...preferences,
                    timezone: e.target.value
                  })}
                  className="input-field"
                >
                  <option value="America/New_York">Eastern Time (ET)</option>
                  <option value="America/Chicago">Central Time (CT)</option>
                  <option value="America/Denver">Mountain Time (MT)</option>
                  <option value="America/Los_Angeles">Pacific Time (PT)</option>
                  <option value="UTC">UTC</option>
                </select>
              </div>

              <button
                onClick={updatePreferences}
                className="w-full btn-primary"
              >
                Save Preferences
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
