import { useAuth } from "@/shims/mocha-auth";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/react-app/components/Layout";
import AdvancedReporting from "@/react-app/components/AdvancedReporting";

export default function Reporting() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/');
    }
  }, [user, isPending, navigate]);

  if (isPending) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-full">
          <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full"></div>
        </div>
      </Layout>
    );
  }

  if (!user) return null;

  return (
    <Layout>
      <div className="p-6">
        <AdvancedReporting />
      </div>
    </Layout>
  );
}
