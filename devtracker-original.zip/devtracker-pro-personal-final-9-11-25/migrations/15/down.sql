
DROP TABLE smart_availability;
DROP TABLE scheduling_rules;
DROP TABLE ai_insights;
DROP TABLE invoice_line_items;
DROP TABLE invoices;
DROP TABLE billing_codes;
DROP TABLE patient_documents;
DROP TABLE patient_portal_access;
DROP TABLE video_consultations;
DROP TABLE custom_dashboards;
DROP TABLE analytics_events;
DROP TABLE notification_preferences;
DROP TABLE notifications;
DROP TABLE team_projects;
DROP TABLE team_members;
DROP TABLE teams;
