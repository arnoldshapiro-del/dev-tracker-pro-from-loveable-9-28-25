import React, { useState, useEffect } from 'react';
import { useAuth } from "@/shims/mocha-auth";
import DataService from "@/react-app/services/DataService";
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  Target,
  Zap,
  BarChart3,
  Lightbulb,
  Star,
  ArrowUp,
  ArrowDown,
  Users,
  GitBranch,
  DollarSign,
  Activity,
  X,
  Eye,
  ThumbsUp,
  ThumbsDown,
  RefreshCw
} from "lucide-react";

interface AIInsight {
  id: number;
  user_id: string;
  insight_type: string;
  target_type: string;
  target_id: number;
  title: string;
  description: string;
  confidence_score: number;
  action_items: string[];
  predicted_impact: string;
  data_sources: string[];
  is_dismissed: boolean;
  is_implemented: boolean;
  created_at: string;
  project_name?: string;
  team_name?: string;
}

interface InsightMetrics {
  total_insights: number;
  pending_insights: number;
  implemented_insights: number;
  high_confidence_insights: number;
  avg_confidence_score: number;
  predicted_credit_savings: number;
  predicted_time_savings: number;
}

interface AIInsightsDashboardProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AIInsightsDashboard({ isOpen, onClose }: AIInsightsDashboardProps) {
  const { user } = useAuth();
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [metrics, setMetrics] = useState<InsightMetrics>({
    total_insights: 0,
    pending_insights: 0,
    implemented_insights: 0,
    high_confidence_insights: 0,
    avg_confidence_score: 0,
    predicted_credit_savings: 0,
    predicted_time_savings: 0
  });
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'high-confidence' | 'implemented'>('pending');
  const [sortBy, setSortBy] = useState<'confidence' | 'date' | 'impact'>('confidence');

  useEffect(() => {
    if (isOpen && user) {
      fetchInsights();
      fetchMetrics();
    }
  }, [isOpen, user]);

  const fetchInsights = async () => {
    try {
      setLoading(true);
      // Mock insights data since this is an advanced feature
      const mockInsights = [
        {
          id: 1,
          user_id: user?.id || 'local-user',
          insight_type: 'optimization',
          target_type: 'project',
          target_id: 1,
          title: 'Credit Usage Optimization',
          description: 'Your AI project spending could be reduced by 25% by switching platforms for certain tasks.',
          confidence_score: 85,
          action_items: ['Review platform usage', 'Test alternative platforms', 'Migrate non-critical tasks'],
          predicted_impact: 'High savings potential',
          data_sources: ['credit_usage', 'platform_performance'],
          is_dismissed: false,
          is_implemented: false,
          created_at: new Date().toISOString()
        }
      ];
      setInsights(mockInsights);
    } catch (error) {
      console.error('Error fetching insights:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMetrics = async () => {
    try {
      // Mock metrics data
      const mockMetrics = {
        total_insights: 1,
        pending_insights: 1,
        implemented_insights: 0,
        high_confidence_insights: 1,
        avg_confidence_score: 85,
        predicted_credit_savings: 250,
        predicted_time_savings: 8
      };
      setMetrics(mockMetrics);
    } catch (error) {
      console.error('Error fetching metrics:', error);
    }
  };

  const generateNewInsights = async () => {
    try {
      setLoading(true);
      // Mock insight generation
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate processing
      await fetchInsights();
      await fetchMetrics();
    } catch (error) {
      console.error('Error generating insights:', error);
    } finally {
      setLoading(false);
    }
  };

  const dismissInsight = async (insightId: number) => {
    try {
      // Update local state immediately
      setInsights(prev => 
        prev.map(insight => 
          insight.id === insightId ? { ...insight, is_dismissed: true } : insight
        )
      );
    } catch (error) {
      console.error('Error dismissing insight:', error);
    }
  };

  const markAsImplemented = async (insightId: number) => {
    try {
      // Update local state immediately
      setInsights(prev => 
        prev.map(insight => 
          insight.id === insightId ? { ...insight, is_implemented: true } : insight
        )
      );
    } catch (error) {
      console.error('Error marking insight as implemented:', error);
    }
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'optimization': return <Zap className="w-5 h-5 text-yellow-500" />;
      case 'cost_saving': return <DollarSign className="w-5 h-5 text-green-500" />;
      case 'performance': return <TrendingUp className="w-5 h-5 text-blue-500" />;
      case 'risk': return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case 'collaboration': return <Users className="w-5 h-5 text-purple-500" />;
      case 'deployment': return <GitBranch className="w-5 h-5 text-indigo-500" />;
      default: return <Lightbulb className="w-5 h-5 text-gray-500" />;
    }
  };

  const getConfidenceColor = (score: number) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 70) return 'text-blue-600 bg-blue-100';
    if (score >= 50) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getImpactIcon = (impact: string) => {
    switch (impact?.toLowerCase()) {
      case 'high': return <ArrowUp className="w-4 h-4 text-green-500" />;
      case 'medium': return <Activity className="w-4 h-4 text-yellow-500" />;
      case 'low': return <ArrowDown className="w-4 h-4 text-gray-500" />;
      default: return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  const filteredInsights = insights.filter(insight => {
    if (filter === 'pending') return !insight.is_implemented && !insight.is_dismissed;
    if (filter === 'high-confidence') return insight.confidence_score >= 80;
    if (filter === 'implemented') return insight.is_implemented;
    return !insight.is_dismissed;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'confidence': return b.confidence_score - a.confidence_score;
      case 'date': return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      case 'impact': 
        const impactOrder = { 'high': 3, 'medium': 2, 'low': 1 };
        return (impactOrder[b.predicted_impact?.toLowerCase() as keyof typeof impactOrder] || 0) - 
               (impactOrder[a.predicted_impact?.toLowerCase() as keyof typeof impactOrder] || 0);
      default: return 0;
    }
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-7xl w-full max-h-[95vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">AI Insights Dashboard</h2>
              <p className="text-sm text-gray-600">Intelligent recommendations to optimize your workflow</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={generateNewInsights}
              disabled={loading}
              className="btn-secondary flex items-center space-x-2 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>Generate Insights</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
        </div>

        {/* Metrics Overview */}
        <div className="p-6 border-b border-gray-200">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
            <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-xs font-medium">Total Insights</p>
                  <p className="text-xl font-bold">{metrics.total_insights}</p>
                </div>
                <Brain className="w-6 h-6 text-blue-200" />
              </div>
            </div>

            <div className="bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-yellow-100 text-xs font-medium">Pending</p>
                  <p className="text-xl font-bold">{metrics.pending_insights}</p>
                </div>
                <Clock className="w-6 h-6 text-yellow-200" />
              </div>
            </div>

            <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-xs font-medium">Implemented</p>
                  <p className="text-xl font-bold">{metrics.implemented_insights}</p>
                </div>
                <CheckCircle className="w-6 h-6 text-green-200" />
              </div>
            </div>

            <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-xs font-medium">High Confidence</p>
                  <p className="text-xl font-bold">{metrics.high_confidence_insights}</p>
                </div>
                <Star className="w-6 h-6 text-purple-200" />
              </div>
            </div>

            <div className="bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-lg p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-indigo-100 text-xs font-medium">Avg Confidence</p>
                  <p className="text-xl font-bold">{Math.round(metrics.avg_confidence_score)}%</p>
                </div>
                <BarChart3 className="w-6 h-6 text-indigo-200" />
              </div>
            </div>

            <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-lg p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-emerald-100 text-xs font-medium">Credit Savings</p>
                  <p className="text-xl font-bold">{metrics.predicted_credit_savings}</p>
                </div>
                <DollarSign className="w-6 h-6 text-emerald-200" />
              </div>
            </div>

            <div className="bg-gradient-to-r from-rose-500 to-rose-600 rounded-lg p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-rose-100 text-xs font-medium">Time Savings</p>
                  <p className="text-xl font-bold">{metrics.predicted_time_savings}h</p>
                </div>
                <Clock className="w-6 h-6 text-rose-200" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Controls */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Filter</label>
                <select
                  value={filter}
                  onChange={(e) => setFilter(e.target.value as any)}
                  className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="all">All insights</option>
                  <option value="pending">Pending action</option>
                  <option value="high-confidence">High confidence</option>
                  <option value="implemented">Implemented</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Sort by</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="confidence">Confidence score</option>
                  <option value="date">Date created</option>
                  <option value="impact">Predicted impact</option>
                </select>
              </div>
            </div>

            <div className="text-sm text-gray-600">
              Showing {filteredInsights.length} of {insights.length} insights
            </div>
          </div>
        </div>

        {/* Insights List */}
        <div className="p-6">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full"></div>
            </div>
          ) : filteredInsights.length === 0 ? (
            <div className="text-center py-12">
              <Brain className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No insights available</h3>
              <p className="text-gray-600 mb-6">
                {filter === 'pending' ? 'All insights have been addressed' : 
                 filter === 'high-confidence' ? 'No high-confidence insights found' :
                 'Generate insights to get AI-powered recommendations'}
              </p>
              <button
                onClick={generateNewInsights}
                className="btn-primary"
              >
                Generate New Insights
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {filteredInsights.map((insight) => (
                <div
                  key={insight.id}
                  className={`border rounded-lg p-6 transition-all hover:shadow-md ${
                    insight.is_implemented ? 'border-green-200 bg-green-50' :
                    insight.is_dismissed ? 'border-gray-200 bg-gray-50 opacity-75' :
                    insight.confidence_score >= 80 ? 'border-purple-200 bg-purple-50' :
                    'border-gray-200 bg-white'
                  }`}
                >
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 mt-1">
                      {getInsightIcon(insight.insight_type)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-lg font-medium text-gray-900">
                              {insight.title}
                            </h3>
                            
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getConfidenceColor(insight.confidence_score)}`}>
                              {insight.confidence_score}% confidence
                            </span>
                            
                            {insight.predicted_impact && (
                              <div className="flex items-center space-x-1">
                                {getImpactIcon(insight.predicted_impact)}
                                <span className="text-sm text-gray-600 capitalize">
                                  {insight.predicted_impact} impact
                                </span>
                              </div>
                            )}
                          </div>
                          
                          <p className="text-gray-700 mb-4">
                            {insight.description}
                          </p>
                          
                          {insight.action_items.length > 0 && (
                            <div className="mb-4">
                              <h4 className="text-sm font-medium text-gray-900 mb-2">Recommended Actions:</h4>
                              <ul className="list-disc list-inside space-y-1">
                                {insight.action_items.map((action, index) => (
                                  <li key={index} className="text-sm text-gray-600">
                                    {action}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <span>Target: {insight.target_type} #{insight.target_id}</span>
                            {insight.project_name && (
                              <span>Project: {insight.project_name}</span>
                            )}
                            <span>Created: {new Date(insight.created_at).toLocaleDateString()}</span>
                            {insight.data_sources.length > 0 && (
                              <span>Sources: {insight.data_sources.join(', ')}</span>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2 ml-4">
                          {!insight.is_implemented && !insight.is_dismissed && (
                            <>
                              <button
                                onClick={() => markAsImplemented(insight.id)}
                                className="p-2 text-green-600 hover:text-green-700 hover:bg-green-100 rounded-lg transition-colors"
                                title="Mark as implemented"
                              >
                                <ThumbsUp className="w-4 h-4" />
                              </button>
                              
                              <button
                                onClick={() => dismissInsight(insight.id)}
                                className="p-2 text-gray-600 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                                title="Dismiss insight"
                              >
                                <ThumbsDown className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          
                          <button
                            className="p-2 text-blue-600 hover:text-blue-700 hover:bg-blue-100 rounded-lg transition-colors"
                            title="View details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      
                      {insight.is_implemented && (
                        <div className="bg-green-100 border border-green-200 rounded-lg p-3">
                          <div className="flex items-center space-x-2">
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            <span className="text-sm font-medium text-green-700">
                              This insight has been implemented
                            </span>
                          </div>
                        </div>
                      )}
                      
                      {insight.is_dismissed && (
                        <div className="bg-gray-100 border border-gray-200 rounded-lg p-3">
                          <div className="flex items-center space-x-2">
                            <X className="w-4 h-4 text-gray-500" />
                            <span className="text-sm font-medium text-gray-700">
                              This insight has been dismissed
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
