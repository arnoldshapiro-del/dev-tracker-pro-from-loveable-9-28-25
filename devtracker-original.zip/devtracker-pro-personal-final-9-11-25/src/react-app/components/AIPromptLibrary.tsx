export default function AIPromptLibrary() {
  return (
    <div className="text-center py-8">
      <h3 className="text-lg font-medium text-gray-900 mb-2">AI Prompt Library</h3>
      <p className="text-gray-500">Prompt templates and library features coming soon...</p>
    </div>
  );
}