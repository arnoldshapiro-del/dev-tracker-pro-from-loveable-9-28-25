
ALTER TABLE user_preferences ADD COLUMN github_token TEXT;
ALTER TABLE user_preferences ADD COLUMN netlify_token TEXT;
