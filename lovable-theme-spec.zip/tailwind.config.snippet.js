// Tailwind config snippet – add to theme.extend.colors
// This maps CSS variables so the UI can switch themes without code changes.
export default {
  theme: {
    extend: {
      colors: {
        bg: 'var(--bg)',
        surface: 'var(--surface)',
        border: 'var(--border)',
        text: 'var(--text)',
        muted: 'var(--muted)',
        accent: {
          1: 'var(--accent-1)',
          2: 'var(--accent-2)',
          3: 'var(--accent-3)',
          4: 'var(--accent-4)',
          5: 'var(--accent-5)',
          6: 'var(--accent-6)',
        },
      },
      borderRadius: { 'xl2': '14px' }
    }
  }
}
